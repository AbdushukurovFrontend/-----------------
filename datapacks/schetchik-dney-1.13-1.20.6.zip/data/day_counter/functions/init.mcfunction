bossbar add day_counter: ""
bossbar set day_counter: color green
bossbar set day_counter: max 24000
bossbar set day_counter: style notched_6

scoreboard objectives add day_counter dummy
scoreboard players set 24000 day_counter 24000
scoreboard players set 1666 day_counter 1666
scoreboard players set 1000 day_counter 1000
scoreboard players set 100 day_counter 100
scoreboard players set 10 day_counter 10

execute unless score display day_counter matches 0..2 run function day_counter:display/bossbar