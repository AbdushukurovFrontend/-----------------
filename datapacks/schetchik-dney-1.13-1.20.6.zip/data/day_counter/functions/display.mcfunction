# Joriy o'yin vaqtini olamiz
execute store result score daytime day_counter run time query daytime
scoreboard players add daytime day_counter 6000
execute store result bossbar day_counter: value run scoreboard players operation daytime day_counter %= 24000 day_counter

# O'yin kuni hisoblagichini olamiz
execute store result score day day_counter run time query day
execute if score daytime day_counter matches ..5999 run scoreboard players set new_day? day_counter 1
execute if score daytime day_counter matches 6000.. run scoreboard players set new_day? day_counter 0
scoreboard players operation day day_counter += new_day? day_counter

# O'yin vaqtini hisoblaymiz
# Soatlar
scoreboard players operation hours day_counter = daytime day_counter
scoreboard players operation hours day_counter /= 1000 day_counter
# Daqiqalar
scoreboard players operation minutes.tens day_counter = daytime day_counter
scoreboard players operation minutes.tens day_counter %= 1000 day_counter
scoreboard players operation minutes.tens day_counter *= 100 day_counter
scoreboard players operation minutes.tens day_counter /= 1666 day_counter
scoreboard players operation minutes.tens day_counter /= 10 day_counter

scoreboard players operation minutes.ones day_counter = daytime day_counter
scoreboard players operation minutes.ones day_counter %= 1000 day_counter
scoreboard players operation minutes.ones day_counter *= 100 day_counter
scoreboard players operation minutes.ones day_counter /= 1666 day_counter
scoreboard players operation minutes.ones day_counter %= 10 day_counter

## Natijani chiqaramiz
# Bossbar
execute if score display day_counter matches 1 run bossbar set day_counter: name [{"text":"Kun ","color":"white"},{"score":{"name":"day","objective":"day_counter"},"color":"yellow"},". Vaqt: ",[{"score":{"name":"hours","objective":"day_counter"},"color":"light_purple"},":",{"score":{"name":"minutes.tens","objective":"day_counter"}},{"score":{"name":"minutes.ones","objective":"day_counter"}}]]
execute if score display day_counter matches 1 run bossbar set day_counter: players @a
# Actionbar
execute if score display day_counter matches 2 run title @a actionbar [{"text":"Kun ","color":"white"},{"score":{"name":"day","objective":"day_counter"},"color":"yellow"},". Vaqt: ",[{"score":{"name":"hours","objective":"day_counter"},"color":"light_purple"},":",{"score":{"name":"minutes.tens","objective":"day_counter"}},{"score":{"name":"minutes.ones","objective":"day_counter"}}]]