scoreboard players set display day_counter 1
bossbar set day_counter: visible true
title @a actionbar ""