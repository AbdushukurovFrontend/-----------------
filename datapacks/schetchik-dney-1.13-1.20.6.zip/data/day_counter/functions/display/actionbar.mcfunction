scoreboard players set display day_counter 2
bossbar set day_counter: visible false