scoreboard players set display day_counter 0
bossbar set day_counter: visible false
title @a actionbar ""