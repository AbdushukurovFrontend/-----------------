bossbar set stream:boss2 visible true
scoreboard players set #boss2saw stream_data 1
execute store result bossbar stream:boss2 value run data get entity @s Health
execute store result score #b2hp stream_data run data get entity @s Health
execute if score #b2hp stream_data matches ..400 unless entity @s[tag=b2p2] run function stream:boss2_p2
execute if score #b2hp stream_data matches ..200 unless entity @s[tag=b2p3] run function stream:boss2_p3
