scoreboard players set @s yordam 0
function stream:guide_one
