scoreboard players set @s rev_t 0
clear @s minecraft:nether_star{aptechka:1b} 1
execute as @e[tag=body,sort=nearest,limit=1] at @s run function stream:revive_target
