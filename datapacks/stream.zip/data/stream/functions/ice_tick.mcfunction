effect give @a[distance=..8] minecraft:slowness 2 1 true
title @a[distance=..8] actionbar {"text":"MUZ AURASI","color":"aqua","bold":true}
