tag @s add boss_p3
tellraw @a[x=45,y=65,z=4,distance=..35] [{"text":"ZINDON TITANI ","color":"dark_red","bold":true},{"text":"oxirgi kuchini ishga soldi!","color":"red"}]
title @a[x=45,y=65,z=4,distance=..35] times 5 40 10
title @a[x=45,y=65,z=4,distance=..35] subtitle {"text":"Oxirgi hujum","color":"gray"}
title @a[x=45,y=65,z=4,distance=..35] title {"text":"3-BOSQICH","color":"dark_red","bold":true}
execute as @a[x=45,y=65,z=4,distance=..35] at @s run playsound minecraft:entity.ender_dragon.growl hostile @s ~ ~ ~ 3 0.6
execute at @a[x=45,y=65,z=4,distance=..35] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=45,y=65,z=4,distance=..35] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=45,y=65,z=4,distance=..35] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=45,y=65,z=4,distance=..35] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=45,y=65,z=4,distance=..35] run summon stray ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=45,y=65,z=4,distance=..35] run summon stray ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
