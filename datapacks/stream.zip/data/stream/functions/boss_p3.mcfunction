tag @s add boss_p3
tellraw @a[distance=..35] [{"text":"ZINDON TITANI ","color":"dark_red","bold":true},{"text":"oxirgi kuchini ishga soldi!","color":"red"}]
title @a[distance=..35] times 5 40 10
title @a[distance=..35] subtitle {"text":"Oxirgi hujum","color":"gray"}
title @a[distance=..35] title {"text":"3-BOSQICH","color":"dark_red","bold":true}
playsound minecraft:entity.ender_dragon.growl hostile @a[distance=..35] ~ ~ ~ 3 0.6
execute at @a[distance=..35] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[distance=..35] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[distance=..35] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[distance=..35] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[distance=..35] run summon stray ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[distance=..35] run summon stray ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
