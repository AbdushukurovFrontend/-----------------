tag @s add boss_p3
tellraw @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] [{"text":"ZINDON TITANI ","color":"dark_red","bold":true},{"text":"oxirgi kuchini ishga soldi!","color":"red"}]
title @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] times 5 40 10
title @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] subtitle {"text":"Oxirgi hujum","color":"gray"}
title @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] title {"text":"3-BOSQICH","color":"dark_red","bold":true}
execute as @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] at @s run playsound minecraft:entity.ender_dragon.growl hostile @s ~ ~ ~ 3 0.6
execute at @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40,gamemode=!spectator] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40,gamemode=!spectator] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40,gamemode=!spectator] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40,gamemode=!spectator] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40,gamemode=!spectator] run summon stray ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40,gamemode=!spectator] run summon stray ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
