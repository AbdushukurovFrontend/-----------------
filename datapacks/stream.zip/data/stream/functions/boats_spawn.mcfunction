kill @e[tag=seaboat]
forceload add 48 -16 80 16
schedule function stream:boats_spawn2 20t
