execute if score #c stream_data matches 0 run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 1
execute if entity @e[type=customnpcs:customnpc,tag=stalker,distance=..12] run function stream:warn12
