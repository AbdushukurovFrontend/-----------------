tag @s remove downed
gamemode adventure @s[gamemode=spectator]
