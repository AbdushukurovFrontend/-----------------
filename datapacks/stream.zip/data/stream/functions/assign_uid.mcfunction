scoreboard players add #uidn stream_data 1
scoreboard players operation @s uid = #uidn stream_data
