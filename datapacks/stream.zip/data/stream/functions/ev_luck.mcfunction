title @a[tag=!in_lobby] times 10 60 15
title @a[tag=!in_lobby] subtitle {"text":"90 soniya baliq ovida omad kuchaydi","color":"gray"}
title @a[tag=!in_lobby] title {"text":"OMAD SOATI!","color":"green","bold":true}
effect give @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator] minecraft:luck 90 3 false
