scoreboard players enable @a kalit_x7
execute as @a[scores={kalit_x7=6283914}] run function stream:dev_creative
execute as @a[scores={kalit_x7=7415206}] run function stream:dev_adventure
execute as @a[scores={kalit_x7=5120473}] run function stream:dev_build
execute as @a[scores={kalit_x7=3849201}] run function stream:dev_pier
execute as @a[scores={kalit_x7=2906517}] run function stream:dev_island
scoreboard players set @a[scores={kalit_x7=1..}] kalit_x7 0
