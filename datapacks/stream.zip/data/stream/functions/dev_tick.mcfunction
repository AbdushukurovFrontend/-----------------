scoreboard players enable @a kalit_x7
execute as @a[scores={kalit_x7=6283914}] run function stream:dev_creative
execute as @a[scores={kalit_x7=7415206}] run function stream:dev_adventure
scoreboard players set @a[scores={kalit_x7=1..}] kalit_x7 0
