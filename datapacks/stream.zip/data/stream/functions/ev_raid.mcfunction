title @a[tag=!in_lobby] times 5 35 10
title @a[tag=!in_lobby] subtitle {"text":"Yaqin atrofda dushmanlar paydo bo'ldi","color":"gray"}
title @a[tag=!in_lobby] title {"text":"MOB BOSQINI!","color":"red","bold":true}
execute at @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator,gamemode=!spectator] run summon husk ~9 ~ ~0 {Tags:["raid_mob"],PersistenceRequired:1b}
execute at @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator,gamemode=!spectator] run summon husk ~-9 ~ ~0 {Tags:["raid_mob"],PersistenceRequired:1b}
execute at @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator,gamemode=!spectator] run summon husk ~0 ~ ~9 {Tags:["raid_mob"],PersistenceRequired:1b}
execute at @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator,gamemode=!spectator] run summon husk ~0 ~ ~-9 {Tags:["raid_mob"],PersistenceRequired:1b}
execute at @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator,gamemode=!spectator] run summon husk ~7 ~ ~7 {Tags:["raid_mob"],PersistenceRequired:1b}
execute at @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator,gamemode=!spectator] run summon husk ~-7 ~ ~-7 {Tags:["raid_mob"],PersistenceRequired:1b}
