tag @a remove downed
gamemode adventure @a[gamemode=spectator]
tp @a[tag=!in_lobby,gamemode=!creative] 17 70 42
kill @e[tag=body]
