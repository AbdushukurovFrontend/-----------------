scoreboard players set #sea_built stream_data 1
tellraw @a[tag=!in_lobby] {"text":"Qora Dengiz paydo bo'lmoqda... (5 soniya)","color":"dark_purple","bold":true}
forceload add 40 -64 220 63
schedule function stream:sea_build2 100t
