scoreboard players remove #lives stream_data 1
tag @s add downed
tag @s add downed_now
gamemode spectator @s
scoreboard players operation #me stream_data = @s uid
execute as @e[type=armor_stand,tag=shadow] if score @s uid = #me stream_data run function stream:make_body
tellraw @a [{"selector":"@s","color":"red","bold":true},{"text":" halok bo'ldi! Jamoada qolgan jonlar: ","color":"red"},{"score":{"name":"#lives","objective":"stream_data"},"color":"yellow","bold":true}]
tag @s remove downed_now
execute if score #lives stream_data matches ..0 run function stream:team_wipe
