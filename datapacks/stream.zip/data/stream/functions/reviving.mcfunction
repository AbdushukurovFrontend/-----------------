scoreboard players add @s rev_t 1
title @s actionbar [{"text":"Qutqarilmoqda... ","color":"green"},{"score":{"name":"@s","objective":"rev_t"},"color":"yellow"},{"text":"/60","color":"gray"}]
execute if score @s rev_t matches 60.. run function stream:do_revive
