scoreboard players operation #me stream_data = @s uid
execute as @a[tag=downed] if score @s uid = #me stream_data run function stream:stand_up
kill @s
