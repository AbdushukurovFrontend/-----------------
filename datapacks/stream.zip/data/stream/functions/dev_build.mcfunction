function stream:sea_build
tellraw @s {"text":"[Sinov] Qora Dengiz qurilmoqda (taxminan 5 soniya). Keyin iskala va orolga o'ting.","color":"green"}
