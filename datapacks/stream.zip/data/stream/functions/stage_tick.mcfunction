execute if score #stage stream_data matches 4 if entity @a[x=52,y=90,z=-15,dx=30,dy=30,dz=30] run function stream:stage5
execute if score #stage stream_data matches 4..5 if entity @a[x=100,y=90,z=-60,dx=120,dy=40,dz=120] run function stream:stage6
