execute as @a[tag=!in_lobby,gamemode=!spectator] run function stream:guide_one
