title @a[tag=!in_lobby] times 10 60 15
title @a[tag=!in_lobby] subtitle {"text":"Stalker ko'rinmay qoldi...","color":"gray"}
title @a[tag=!in_lobby] title {"text":"TUMAN!","color":"dark_gray","bold":true}
effect give @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator] minecraft:darkness 40 0 true
effect give @e[type=customnpcs:customnpc,tag=stalker] minecraft:invisibility 40 0 true
