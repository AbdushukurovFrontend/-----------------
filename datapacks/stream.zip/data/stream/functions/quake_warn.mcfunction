scoreboard players set #bt stream_data 0
title @a[x=45,y=65,z=4,distance=..35] actionbar {"text":"SAKRANG! Yerdan uzoqlash!","color":"red","bold":true}
execute as @a[x=45,y=65,z=4,distance=..35] at @s run playsound minecraft:entity.warden.sonic_charge hostile @s ~ ~ ~ 2 1
schedule function stream:quake_hit 30t
