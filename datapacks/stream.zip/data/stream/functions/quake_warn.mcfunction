scoreboard players set #bt stream_data 0
title @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] actionbar {"text":"SAKRANG! Yerdan uzoqlash!","color":"red","bold":true}
execute as @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] at @s run playsound minecraft:entity.warden.sonic_charge hostile @s ~ ~ ~ 2 1
schedule function stream:quake_hit 30t
