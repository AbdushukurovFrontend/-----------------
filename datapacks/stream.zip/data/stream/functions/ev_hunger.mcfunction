title @a[tag=!in_lobby] times 10 60 15
title @a[tag=!in_lobby] subtitle {"text":"30 soniya qorning och bo'ladi","color":"gray"}
title @a[tag=!in_lobby] title {"text":"OCHLIK!","color":"gold","bold":true}
effect give @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator] minecraft:hunger 30 3 false
