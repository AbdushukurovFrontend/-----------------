tag @s add b2p3
tellraw @a[x=160,y=108,z=0,distance=..60] [{"text":"DENGIZ QIROLI ","color":"dark_purple","bold":true},{"text":"oxirgi kuchini ishga soldi!","color":"light_purple"}]
title @a[x=160,y=108,z=0,distance=..60] times 5 40 10
title @a[x=160,y=108,z=0,distance=..60] subtitle {"text":"Oxirgi hujum","color":"gray"}
title @a[x=160,y=108,z=0,distance=..60] title {"text":"3-BOSQICH","color":"dark_purple","bold":true}
execute as @a[x=160,y=108,z=0,distance=..60] at @s run playsound minecraft:entity.ender_dragon.growl hostile @s ~ ~ ~ 3 0.7
execute at @a[x=160,y=108,z=0,distance=..60,gamemode=!spectator] run summon wither_skeleton ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=160,y=108,z=0,distance=..60,gamemode=!spectator] run summon wither_skeleton ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=160,y=108,z=0,distance=..60,gamemode=!spectator] run summon wither_skeleton ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=160,y=108,z=0,distance=..60,gamemode=!spectator] run summon drowned ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=160,y=108,z=0,distance=..60,gamemode=!spectator] run summon drowned ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=160,y=108,z=0,distance=..60,gamemode=!spectator] run summon drowned ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
