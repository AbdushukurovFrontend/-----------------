execute store result score #dt stream_data run time query daytime
execute if score #night stream_data matches 0 if score #dt stream_data matches 13000.. run function stream:night_start
execute if score #night stream_data matches 1 if score #dt stream_data matches ..12999 run function stream:night_end
execute if score #waveactive stream_data matches 1 run function stream:wave_tick
