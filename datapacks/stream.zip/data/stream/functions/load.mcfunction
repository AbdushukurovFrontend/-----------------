scoreboard objectives add stream_data dummy
scoreboard objectives add stream_death deathCount
scoreboard objectives add stream_pdeaths deathCount {"text":"O'limlar","color":"red"}
scoreboard objectives add stream_info dummy {"text":"BALIQ OVLASH","color":"aqua","bold":true}
scoreboard objectives setdisplay sidebar stream_info
scoreboard objectives setdisplay list stream_pdeaths
scoreboard players set #60 stream_data 60
scoreboard players set #10 stream_data 10
scoreboard players set #8 stream_data 8
scoreboard players set #3 stream_data 3
scoreboard players add #deaths stream_data 0
scoreboard players add #best stream_data 0
scoreboard players add #sec stream_data 0
scoreboard players add #active stream_data 0
scoreboard players add #c stream_data 0
scoreboard players add #night stream_data 0
scoreboard players add #wave stream_data 0
scoreboard players add #waveactive stream_data 0
scoreboard players add #bm stream_data 0
scoreboard players add #bt stream_data 0
scoreboard players add #evt stream_data 0
execute unless score #evt stream_data matches 1.. run scoreboard players set #evt stream_data 180
scoreboard players add §cOlimlar stream_info 0
scoreboard players add §eVaqt-son stream_info 0
scoreboard players add §aRekord-son stream_info 0
scoreboard players add §dKecha stream_info 0
bossbar add stream:boss {"text":"ZINDON TITANI","color":"dark_red","bold":true}
bossbar set stream:boss color red
bossbar set stream:boss style notched_10
bossbar set stream:boss max 400
bossbar set stream:boss visible false
bossbar add stream:event {"text":"Keyingi hodisa","color":"yellow"}
bossbar set stream:event color yellow
bossbar set stream:event style progress
bossbar set stream:event max 180
bossbar set stream:event visible false
bossbar add stream:wave {"text":"KECHA","color":"red"}
bossbar set stream:wave color red
bossbar set stream:wave style notched_6
bossbar set stream:wave visible false
scoreboard objectives add uid dummy
scoreboard objectives add rev_t dummy
scoreboard objectives add stream_kills totalKillCount
scoreboard objectives add yordam trigger
scoreboard players add #uidn stream_data 0
scoreboard players add #killacc stream_data 0
scoreboard players add #stage stream_data 0
scoreboard players add #sea_built stream_data 0
scoreboard players add #sea_ready stream_data 0
scoreboard players add #bosssaw stream_data 0
scoreboard players add #boss2saw stream_data 0
execute unless score #lives stream_data matches 0.. run scoreboard players set #lives stream_data 5
scoreboard players add §cJonlar stream_info 0
bossbar add stream:goal {"text":"MAQSAD","color":"yellow"}
bossbar set stream:goal color blue
bossbar set stream:goal style progress
bossbar set stream:goal visible false
bossbar add stream:boss2 {"text":"DENGIZ QIROLI","color":"dark_purple","bold":true}
bossbar set stream:boss2 color purple
bossbar set stream:boss2 style notched_10
bossbar set stream:boss2 max 800
bossbar set stream:boss2 visible false
