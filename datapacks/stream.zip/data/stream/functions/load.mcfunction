scoreboard objectives add stream_data dummy
scoreboard objectives add stream_death deathCount
scoreboard objectives add stream_pdeaths deathCount {"text":"O'limlar","color":"red"}
scoreboard objectives add stream_info dummy {"text":"BALIQ OVLASH","color":"aqua","bold":true}
scoreboard objectives setdisplay sidebar stream_info
scoreboard objectives setdisplay list stream_pdeaths
scoreboard players set #60 stream_data 60
scoreboard players set #10 stream_data 10
scoreboard players set #8 stream_data 8
scoreboard players set #3 stream_data 3
scoreboard players add #deaths stream_data 0
scoreboard players add #best stream_data 0
scoreboard players add #sec stream_data 0
scoreboard players add #active stream_data 0
scoreboard players add #c stream_data 0
scoreboard players add #night stream_data 0
scoreboard players add #wave stream_data 0
scoreboard players add #waveactive stream_data 0
scoreboard players add #bm stream_data 0
scoreboard players add #bt stream_data 0
scoreboard players add #evt stream_data 0
execute unless score #evt stream_data matches 1.. run scoreboard players set #evt stream_data 180
scoreboard players add §cOlimlar stream_info 0
scoreboard players add §eVaqt-son stream_info 0
scoreboard players add §aRekord-son stream_info 0
scoreboard players add §dKecha stream_info 0
bossbar add stream:boss {"text":"ZINDON TITANI","color":"dark_red","bold":true}
bossbar set stream:boss color red
bossbar set stream:boss style notched_10
bossbar set stream:boss max 400
bossbar set stream:boss visible false
bossbar add stream:event {"text":"Keyingi hodisa","color":"yellow"}
bossbar set stream:event color yellow
bossbar set stream:event style progress
bossbar set stream:event max 180
bossbar set stream:event visible false
bossbar add stream:wave {"text":"KECHA","color":"red"}
bossbar set stream:wave color red
bossbar set stream:wave style notched_6
bossbar set stream:wave visible false
