# Hisoblagichlar
scoreboard objectives add stream_data dummy
scoreboard objectives add stream_death deathCount
scoreboard objectives add stream_info dummy {"text":"BALIQ OVLASH","color":"aqua","bold":true}
scoreboard objectives setdisplay sidebar stream_info
scoreboard players set #60 stream_data 60
scoreboard players set #10 stream_data 10
scoreboard players add #deaths stream_data 0
scoreboard players add #best stream_data 0
scoreboard players add #sec stream_data 0
scoreboard players add #active stream_data 0
scoreboard players add #c stream_data 0
scoreboard players add §cOlimlar stream_info 0
scoreboard players add §eVaqt-son stream_info 0
scoreboard players add §aRekord-son stream_info 0
# Boss bossbar
bossbar add stream:boss {"text":"ZINDON TITANI","color":"dark_red","bold":true}
bossbar set stream:boss color red
bossbar set stream:boss style notched_10
bossbar set stream:boss max 400
bossbar set stream:boss visible false
