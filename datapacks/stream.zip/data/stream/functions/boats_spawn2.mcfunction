summon boat 64 105.5 -3 {Type:"dark_oak",Tags:["seaboat"]}
summon boat 64 105.5 -1 {Type:"dark_oak",Tags:["seaboat"]}
summon boat 64 105.5 1 {Type:"dark_oak",Tags:["seaboat"]}
summon boat 64 105.5 3 {Type:"dark_oak",Tags:["seaboat"]}
forceload remove 48 -16 80 16
tellraw @a[tag=!in_lobby] {"text":"Qayiqlar tayyor! Iskaladan (X 50-62, Z 0) qayiqqa o'ting va sharqqa suzing.","color":"aqua","bold":true}
