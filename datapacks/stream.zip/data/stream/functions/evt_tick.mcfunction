scoreboard players remove #evt stream_data 1
scoreboard players operation #em stream_data = #evt stream_data
scoreboard players operation #em stream_data /= #60 stream_data
scoreboard players operation #es stream_data = #evt stream_data
scoreboard players operation #es stream_data %= #60 stream_data
scoreboard players operation #e10 stream_data = #es stream_data
scoreboard players operation #e10 stream_data /= #10 stream_data
scoreboard players operation #e1 stream_data = #es stream_data
scoreboard players operation #e1 stream_data %= #10 stream_data
execute if score #bm stream_data matches 1.. run scoreboard players remove #bm stream_data 1
execute if score #bm stream_data matches 0 if entity @e[tag=blackmarket] run function stream:bm_close
execute if score #evt stream_data matches ..0 run function stream:ev_roll
