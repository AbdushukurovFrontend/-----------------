scoreboard players remove #evt stream_data 1
scoreboard players operation #em stream_data = #evt stream_data
scoreboard players operation #em stream_data /= #60 stream_data
scoreboard players operation #es stream_data = #evt stream_data
scoreboard players operation #es stream_data %= #60 stream_data
scoreboard players operation #e10 stream_data = #es stream_data
scoreboard players operation #e10 stream_data /= #10 stream_data
scoreboard players operation #e1 stream_data = #es stream_data
scoreboard players operation #e1 stream_data %= #10 stream_data
execute store result bossbar stream:event value run scoreboard players get #evt stream_data
bossbar set stream:event players @a[tag=!in_lobby]
bossbar set stream:event name [{"text":"Keyingi hodisa: ","color":"yellow"},{"score":{"name":"#em","objective":"stream_data"},"color":"white","bold":true},{"text":":","color":"white","bold":true},{"score":{"name":"#e10","objective":"stream_data"},"color":"white","bold":true},{"score":{"name":"#e1","objective":"stream_data"},"color":"white","bold":true}]
execute if score #bm stream_data matches 1.. run scoreboard players remove #bm stream_data 1
execute if score #bm stream_data matches 0 if entity @e[tag=blackmarket] run function stream:bm_close
execute if score #evt stream_data matches ..0 run function stream:ev_roll
