tag @s remove shadow
tag @s add body
data merge entity @s {Invisible:0b,Marker:0b,NoGravity:1b,Glowing:1b,Invulnerable:1b,DisabledSlots:4144959,CustomNameVisible:1b,CustomName:'{"text":"Yiqilgan sherik","color":"red"}',ArmorItems:[{id:"minecraft:leather_boots",Count:1b},{id:"minecraft:leather_leggings",Count:1b},{id:"minecraft:leather_chestplate",Count:1b},{id:"minecraft:skeleton_skull",Count:1b}]}
tp @a[tag=downed_now] @s
