scoreboard players set #boss2saw stream_data 0
kill @e[tag=boss_minion]
title @a[tag=!in_lobby] times 10 60 15
title @a[tag=!in_lobby] subtitle {"text":"Xarita yakunlanmoqda...","color":"gray"}
title @a[tag=!in_lobby] title {"text":"DENGIZ QIROLI YENGILDI!","color":"gold","bold":true}
schedule function stream:boss2_tp 80t
