scoreboard players set #active stream_data 1
scoreboard players set #sec stream_data 0
scoreboard players set #ticks stream_data 0
scoreboard players set #evt stream_data 180
scoreboard players set #wave stream_data 0
scoreboard players set #night stream_data 0
function stream:calc
bossbar set stream:event players @a[tag=!in_lobby]
bossbar set stream:event visible true
scoreboard players set #lives stream_data 5
scoreboard players set #stage stream_data 1
scoreboard players set #killacc stream_data 0
function stream:goal_update
function stream:tutorial
function stream:boss1_ensure
execute if score #sea_built stream_data matches 1 run function stream:boss2_ensure
