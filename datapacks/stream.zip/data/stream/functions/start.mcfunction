scoreboard players set #active stream_data 1
scoreboard players set #sec stream_data 0
scoreboard players set #ticks stream_data 0
scoreboard players set #evt stream_data 180
scoreboard players set #wave stream_data 0
scoreboard players set #night stream_data 0
function stream:calc
bossbar set stream:event players @a[tag=!in_lobby]
bossbar set stream:event visible true
