scoreboard players set #active stream_data 1
scoreboard players set #sec stream_data 0
scoreboard players set #ticks stream_data 0
function stream:calc
