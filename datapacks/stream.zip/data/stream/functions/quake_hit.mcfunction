execute as @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40,nbt={OnGround:1b}] at @s run damage @s 6 minecraft:magic
execute as @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] at @s run particle minecraft:explosion ~ ~ ~ 0.5 0.1 0.5 0 5
execute as @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] at @s run playsound minecraft:entity.generic.explode hostile @s ~ ~ ~ 1 0.6
