tag @a remove downed
kill @e[tag=body]
gamemode adventure @a[gamemode=spectator]
tp @a[tag=!in_lobby,gamemode=!creative] 22 76 7
