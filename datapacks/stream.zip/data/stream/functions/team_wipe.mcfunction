tellraw @a {"text":"Jamoa yutqazdi! Hammasi boshidan boshlanadi.","color":"dark_red","bold":true}
tag @a remove downed
kill @e[tag=body]
kill @e[tag=shadow]
kill @e[tag=kit]
gamemode adventure @a[gamemode=spectator]
tp @a[tag=!in_lobby,gamemode=!creative] 22 76 7
scoreboard players set #lives stream_data 5
