scoreboard players set #bosssaw stream_data 0
scoreboard players set #stage stream_data 4
function stream:goal_update
title @a[tag=!in_lobby] times 10 60 15
title @a[tag=!in_lobby] subtitle {"text":"Qizil shulkerni qo'lga oling: Qora Dengiz portali","color":"gray"}
title @a[tag=!in_lobby] title {"text":"BOSS YENGILDI!","color":"gold","bold":true}
execute unless score #sea_built stream_data matches 1 run function stream:sea_build
execute if score #sea_built stream_data matches 1 run function stream:boats_spawn
