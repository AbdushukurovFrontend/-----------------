scoreboard players set #bosssaw stream_data 0
scoreboard players set #stage stream_data 4
function stream:goal_update
title @a[tag=!in_lobby] times 5 35 10
title @a[tag=!in_lobby] subtitle {"text":"Qizil shulkerni qo'lga oling: Qora Dengiz portali","color":"gray"}
title @a[tag=!in_lobby] title {"text":"BOSS YENGILDI!","color":"gold","bold":true}
function stream:boats_spawn
