fill 123 100 -42 197 100 42 deepslate
fill 121 101 -44 199 101 44 deepslate
fill 119 102 -46 201 102 46 deepslate
fill 117 103 -48 203 103 48 deepslate
fill 115 104 -50 205 105 50 blackstone
fill 119 106 -46 201 106 46 blackstone
fill 119 107 -46 201 107 46 deepslate_tiles
fill 130 107 -35 145 107 -25 soul_soil
fill 175 107 25 190 107 38 soul_soil
fill 125 107 20 138 107 32 soul_sand
fill 115 100 -50 126 105 -50 water
fill 115 106 -50 126 107 -50 air
fill 115 100 -49 125 105 -49 water
fill 115 106 -49 125 107 -49 air
fill 115 100 -48 124 105 -48 water
fill 115 106 -48 124 107 -48 air
fill 115 100 -47 123 105 -47 water
fill 115 106 -47 123 107 -47 air
fill 115 100 -46 122 105 -46 water
fill 115 106 -46 122 107 -46 air
fill 115 100 -45 121 105 -45 water
fill 115 106 -45 121 107 -45 air
fill 115 100 -44 120 105 -44 water
fill 115 106 -44 120 107 -44 air
fill 115 100 -43 119 105 -43 water
fill 115 106 -43 119 107 -43 air
fill 115 100 -42 118 105 -42 water
fill 115 106 -42 118 107 -42 air
fill 115 100 -41 117 105 -41 water
fill 115 106 -41 117 107 -41 air
fill 115 100 -40 116 105 -40 water
fill 115 106 -40 116 107 -40 air
fill 115 100 -39 115 105 -39 water
fill 115 106 -39 115 107 -39 air
fill 194 100 -50 205 105 -50 water
fill 194 106 -50 205 107 -50 air
fill 195 100 -49 205 105 -49 water
fill 195 106 -49 205 107 -49 air
fill 196 100 -48 205 105 -48 water
fill 196 106 -48 205 107 -48 air
fill 197 100 -47 205 105 -47 water
fill 197 106 -47 205 107 -47 air
fill 198 100 -46 205 105 -46 water
fill 198 106 -46 205 107 -46 air
fill 199 100 -45 205 105 -45 water
fill 199 106 -45 205 107 -45 air
fill 200 100 -44 205 105 -44 water
fill 200 106 -44 205 107 -44 air
fill 201 100 -43 205 105 -43 water
fill 201 106 -43 205 107 -43 air
fill 202 100 -42 205 105 -42 water
fill 202 106 -42 205 107 -42 air
fill 203 100 -41 205 105 -41 water
fill 203 106 -41 205 107 -41 air
fill 204 100 -40 205 105 -40 water
fill 204 106 -40 205 107 -40 air
fill 205 100 -39 205 105 -39 water
fill 205 106 -39 205 107 -39 air
fill 115 100 50 126 105 50 water
fill 115 106 50 126 107 50 air
fill 115 100 49 125 105 49 water
fill 115 106 49 125 107 49 air
fill 115 100 48 124 105 48 water
fill 115 106 48 124 107 48 air
fill 115 100 47 123 105 47 water
fill 115 106 47 123 107 47 air
fill 115 100 46 122 105 46 water
fill 115 106 46 122 107 46 air
fill 115 100 45 121 105 45 water
fill 115 106 45 121 107 45 air
fill 115 100 44 120 105 44 water
fill 115 106 44 120 107 44 air
fill 115 100 43 119 105 43 water
fill 115 106 43 119 107 43 air
fill 115 100 42 118 105 42 water
fill 115 106 42 118 107 42 air
fill 115 100 41 117 105 41 water
fill 115 106 41 117 107 41 air
fill 115 100 40 116 105 40 water
fill 115 106 40 116 107 40 air
fill 115 100 39 115 105 39 water
fill 115 106 39 115 107 39 air
fill 194 100 50 205 105 50 water
fill 194 106 50 205 107 50 air
fill 195 100 49 205 105 49 water
fill 195 106 49 205 107 49 air
fill 196 100 48 205 105 48 water
fill 196 106 48 205 107 48 air
fill 197 100 47 205 105 47 water
fill 197 106 47 205 107 47 air
fill 198 100 46 205 105 46 water
fill 198 106 46 205 107 46 air
fill 199 100 45 205 105 45 water
fill 199 106 45 205 107 45 air
fill 200 100 44 205 105 44 water
fill 200 106 44 205 107 44 air
fill 201 100 43 205 105 43 water
fill 201 106 43 205 107 43 air
fill 202 100 42 205 105 42 water
fill 202 106 42 205 107 42 air
fill 203 100 41 205 105 41 water
fill 203 106 41 205 107 41 air
fill 204 100 40 205 105 40 water
fill 204 106 40 205 107 40 air
fill 205 100 39 205 105 39 water
fill 205 106 39 205 107 39 air
fill 143 107 -17 177 107 17 polished_blackstone
fill 142 108 -18 178 117 18 deepslate_bricks hollow
fill 142 108 -2 142 111 2 air
fill 139 108 -21 145 124 -15 deepslate_tiles hollow
fill 141 125 -19 143 126 -17 sea_lantern
fill 175 108 -21 181 124 -15 deepslate_tiles hollow
fill 177 125 -19 179 126 -17 sea_lantern
fill 139 108 15 145 124 21 deepslate_tiles hollow
fill 141 125 17 143 126 19 sea_lantern
fill 175 108 15 181 124 21 deepslate_tiles hollow
fill 177 125 17 179 126 19 sea_lantern
setblock 150 108 -8 soul_campfire
setblock 170 108 -8 soul_campfire
setblock 150 108 8 soul_campfire
setblock 170 108 8 soul_campfire
fill 119 107 -2 141 107 2 blackstone_bricks
setblock 122 108 -3 lantern
setblock 122 108 3 lantern
setblock 130 108 -3 lantern
setblock 130 108 3 lantern
setblock 138 108 -3 lantern
setblock 138 108 3 lantern
fill 121 108 -13 123 126 -11 white_concrete
fill 121 127 -13 123 128 -11 sea_lantern
setblock 130 108 -30 chest[facing=south]{LootTable:"minecraft:chests/buried_treasure"} replace
setblock 190 108 -30 chest[facing=south]{LootTable:"minecraft:chests/buried_treasure"} replace
setblock 190 108 30 chest[facing=north]{LootTable:"minecraft:chests/buried_treasure"} replace
setblock 130 108 30 chest[facing=north]{LootTable:"minecraft:chests/buried_treasure"} replace
setblock 160 108 -38 chest[facing=south]{LootTable:"minecraft:chests/buried_treasure"} replace
setblock 160 108 38 chest[facing=north]{LootTable:"minecraft:chests/buried_treasure"} replace
fill 50 106 -2 62 106 2 dark_oak_planks
fill 50 100 -2 50 105 -2 dark_oak_fence
setblock 50 107 -2 lantern
fill 62 100 -2 62 105 -2 dark_oak_fence
setblock 62 107 -2 lantern
fill 50 100 2 50 105 2 dark_oak_fence
setblock 50 107 2 lantern
fill 62 100 2 62 105 2 dark_oak_fence
setblock 62 107 2 lantern
fill 75 100 -7 75 109 -7 blackstone
setblock 75 110 -7 sea_lantern
fill 75 100 7 75 109 7 blackstone
setblock 75 110 7 sea_lantern
fill 95 100 -7 95 109 -7 blackstone
setblock 95 110 -7 sea_lantern
fill 95 100 7 95 109 7 blackstone
setblock 95 110 7 sea_lantern
fill 110 100 -7 110 109 -7 blackstone
setblock 110 110 -7 sea_lantern
fill 110 100 7 110 109 7 blackstone
setblock 110 110 7 sea_lantern
summon wither_skeleton 140 108 -25 {Tags:["sea_mob"],PersistenceRequired:1b}
summon wither_skeleton 180 108 -25 {Tags:["sea_mob"],PersistenceRequired:1b}
summon wither_skeleton 140 108 25 {Tags:["sea_mob"],PersistenceRequired:1b}
summon wither_skeleton 180 108 25 {Tags:["sea_mob"],PersistenceRequired:1b}
summon wither_skeleton 160 108 -30 {Tags:["sea_mob"],PersistenceRequired:1b}
summon wither_skeleton 160 108 30 {Tags:["sea_mob"],PersistenceRequired:1b}
summon wither_skeleton 135 108 0 {Tags:["sea_mob"],PersistenceRequired:1b}
summon wither_skeleton 185 108 0 {Tags:["sea_mob"],PersistenceRequired:1b}
summon wither_skeleton 150 108 -28 {Tags:["sea_mob"],PersistenceRequired:1b}
summon wither_skeleton 170 108 28 {Tags:["sea_mob"],PersistenceRequired:1b}
summon drowned 78 104 -5 {Tags:["sea_mob"],PersistenceRequired:1b}
summon drowned 86 104 6 {Tags:["sea_mob"],PersistenceRequired:1b}
summon drowned 98 104 -8 {Tags:["sea_mob"],PersistenceRequired:1b}
summon drowned 104 104 4 {Tags:["sea_mob"],PersistenceRequired:1b}
summon guardian 72 100 0 {Tags:["sea_mob"],PersistenceRequired:1b}
summon guardian 92 100 -2 {Tags:["sea_mob"],PersistenceRequired:1b}
summon customnpcs:customnpc 125.5 108 5.5 {ReturnToStart: 1b, Brain: {memories: {}}, NpcInv: [{Slot: 0b, id: "minecraft:potion", Count: 1b, tag: {CustomPotionColor: 12157439, CustomPotionEffects: [{Duration: 9600, Ambient: 1b, Id: 10, Amplifier: 2, ShowIcon: 0b}, {Duration: 9600, Ambient: 1b, Id: 5, Amplifier: 1, ShowIcon: 0b}, {Duration: 9600, Ambient: 1b, Id: 1, Amplifier: 3, ShowIcon: 0b}], HideFlags: 3, display: {Name: '["",{"text":"KAVA","italic":false,"color":"light_purple","bold":true},{"text":" ichimligi","italic":false}]'}, Enchantments: [{}]}}, {Slot: 1b, id: "minecraft:potion", Count: 1b, tag: {CustomPotionColor: 1908001, CustomPotionEffects: [{Duration: 3600, Id: 21, Amplifier: 4}, {Duration: 4800, Id: 1, Amplifier: 1}, {Duration: 4800, Id: 27, Amplifier: 5}], display: {Lore: ['["",{"text":"( Omadsizlik effekti - baliq ovida yomon ov beradi )","italic":false,"color":"gray"}]'], Name: '["",{"text":"BLAVOD","italic":false,"bold":true,"color":"dark_gray"},{"text":" ichimligi","italic":false,"color":"aqua"}]'}}}, {Slot: 2b, id: "minecraft:potion", Count: 1b, tag: {CustomPotionColor: 4055389, CustomPotionEffects: [{Duration: 4800, Id: 8, Amplifier: 2}, {Duration: 4800, Id: 1, Amplifier: 1}], display: {Name: '["",{"text":"ABSENT","italic":false,"color":"green","bold":true},{"text":" ichimligi","italic":false,"color":"aqua"}]'}, Enchantments: [{}]}}, {Slot: 3b, id: "minecraft:potion", Count: 1b, tag: {CustomPotionColor: 15928615, CustomPotionEffects: [{Duration: 1200, Id: 5, Amplifier: 2}, {Duration: 1200, Id: 10, Amplifier: 0}, {Duration: 1200, Id: 2, Amplifier: 1}], display: {Name: '["",{"text":"QON","italic":false,"bold":true,"color":"dark_red"},{"text":" eliksiri","italic":false}]'}, Enchantments: [{}]}}, {Slot: 4b, id: "minecraft:potion", Count: 1b, tag: {CustomPotionColor: 5482429, CustomPotionEffects: [{Duration: 9600, Ambient: 1b, Id: 21, Amplifier: 1, ShowIcon: 0b}, {Duration: 9600, Ambient: 1b, Id: 1, Amplifier: 1, ShowIcon: 0b}, {Duration: 50, Id: 25, Amplifier: 1}], HideFlags: 3, display: {Name: '["",{"text":"MOXITO","italic":false,"color":"dark_aqua","bold":true},{"text":" ichimligi","italic":false}]'}, Enchantments: [{}]}}], BossColor: 0, PotionEffect: 0, Size: 5, stopAndInteract: 1b, Resistances: {Arrow: 1.0f, Explosion: 1.0f, Knockback: 1.0f, Melee: 1.0f}, BossBar: 2b, RespawnTime: 60, NpcAngrySound: "", ReactsToFire: 0b, IgnoreCobweb: 0b, PositionOffsetZ: 5.0f, PositionOffsetY: 5.0f, PositionOffsetX: 5.0f, CanUpdate: 1b, LootMode: 0, TransformHasAI: 0b, AttackStrenght: 5, PersistenceRequired: 0b, id: "customnpcs:customnpc", IsStatue: 0b, MovingPatern: 0, NpcLines: {Lines: []}, DefendFaction: 0b, FireIndirect: 0, NpcVisible: 0, LinkedNpcName: "", NpcScenes: {Scenes: []}, HitSound: "minecraft:entity.arrow.hit", FindShelter: 2, Orientation: 0, ScriptLanguage: "ECMAScript", HandItems: [{}, {}], KnockBack: 0, TransformHasJob: 0b, ArmorDropChances: [0.08500000089406967f, 0.08500000089406967f, 0.08500000089406967f, 0.08500000089406967f], BurnInSun: 0b, TraderSold: {NpcMiscInv: [{Slot: 0b, id: "minecraft:potion", Count: 1b, tag: {CustomPotionColor: 12157439, CustomPotionEffects: [{Duration: 9600, Ambient: 1b, Id: 10, Amplifier: 2, ShowIcon: 0b}, {Duration: 9600, Ambient: 1b, Id: 5, Amplifier: 1, ShowIcon: 0b}, {Duration: 9600, Ambient: 1b, Id: 1, Amplifier: 3, ShowIcon: 0b}], HideFlags: 3, display: {Name: '["",{"text":"KAVA","italic":false,"color":"light_purple","bold":true},{"text":" ichimligi","italic":false}]'}, Enchantments: [{}]}}, {Slot: 1b, id: "minecraft:potion", Count: 1b, tag: {Potion: "minecraft:long_swiftness"}}, {Slot: 2b, id: "minecraft:diamond_helmet", Count: 1b, tag: {Damage: 0}}, {Slot: 3b, id: "minecraft:potion", Count: 1b, tag: {CustomPotionColor: 4055389, CustomPotionEffects: [{Duration: 4800, Id: 8, Amplifier: 2}, {Duration: 4800, Id: 1, Amplifier: 1}], display: {Name: '["",{"text":"ABSENT","italic":false,"color":"green","bold":true},{"text":" ichimligi","italic":false,"color":"aqua"}]'}, Enchantments: [{}]}}, {Slot: 4b, id: "minecraft:totem_of_undying", Count: 1b}, {Slot: 5b, id: "minecraft:splash_potion", Count: 1b, tag: {Potion: "minecraft:harming"}}, {Slot: 6b, id: "minecraft:potion", Count: 1b, tag: {CustomPotionColor: 1908001, CustomPotionEffects: [{Duration: 3600, Id: 21, Amplifier: 4}, {Duration: 4800, Id: 1, Amplifier: 1}, {Duration: 4800, Id: 27, Amplifier: 5}], display: {Lore: ['["",{"text":"( Omadsizlik effekti - baliq ovida yomon ov beradi )","italic":false,"color":"gray"}]'], Name: '["",{"text":"BLAVOD","italic":false,"bold":true,"color":"dark_gray"},{"text":" ichimligi","italic":false,"color":"aqua"}]'}}}, {Slot: 7b, id: "minecraft:potion", Count: 1b, tag: {CustomPotionColor: 5482429, CustomPotionEffects: [{Duration: 9600, Ambient: 1b, Id: 21, Amplifier: 1, ShowIcon: 0b}, {Duration: 9600, Ambient: 1b, Id: 1, Amplifier: 1, ShowIcon: 0b}, {Duration: 50, Id: 25, Amplifier: 1}], HideFlags: 3, display: {Name: '["",{"text":"MOXITO","italic":false,"color":"dark_aqua","bold":true},{"text":" ichimligi","italic":false}]'}, Enchantments: [{}]}}, {Slot: 8b, id: "minecraft:shield", Count: 1b, tag: {Damage: 0}}, {Slot: 9b, id: "minecraft:netherite_sword", Count: 1b, tag: {Damage: 0}}, {Slot: 10b, id: "minecraft:splash_potion", Count: 1b, tag: {Potion: "minecraft:strong_harming"}}, {Slot: 11b, id: "minecraft:tipped_arrow", Count: 48b, tag: {Potion: "minecraft:long_poison"}}, {Slot: 12b, id: "minecraft:potion", Count: 1b, tag: {CustomPotionColor: 15928615, CustomPotionEffects: [{Duration: 1200, Id: 5, Amplifier: 2}, {Duration: 1200, Id: 10, Amplifier: 0}, {Duration: 1200, Id: 2, Amplifier: 1}], display: {Name: '["",{"text":"QON","italic":false,"bold":true,"color":"dark_red"},{"text":" eliksiri","italic":false}]'}, Enchantments: [{}]}}, {Slot: 13b, id: "minecraft:golden_apple", Count: 5b}, {Slot: 14b, id: "minecraft:cooked_mutton", Count: 15b}, {Slot: 15b, id: "minecraft:suspicious_stew", Count: 1b, tag: {Effects: [{EffectDuration: 7, "forge:effect_id": "minecraft:saturation", EffectId: 23}]}}, {Slot: 16b, id: "minecraft:enchanted_golden_apple", Count: 1b}, {Slot: 17b, id: "minecraft:cooked_mutton", Count: 10b}]}, StandingState: 0, ShowLayers: 1b, AttackInvisible: 0b, NpcInteractNPCLines: {Lines: []}, WalkingRange: 10, ShotCount: 1, pDur: 5, TraderIgnoreDamage: 0b, AttackRange: 2, ActiveRange: 32, NpcKillLines: {Lines: []}, PotionImmune: 0b, AvoidsSun: 0b, Texture: "customnpcs:textures/entity/humanmale/steve.png", NpcJob: 0, BurstCount: 1, NpcAttackLines: {Lines: []}, pSpeed: 10, pArea: 0, pImpact: 0, MoveState: 0, pRender3D: 1b, CombatRegen: 1, NpcsTimers: [], MarkovGender: 0, pEffect: 0, DistanceToMelee: 0, NpcStepSound: "", FireRate: 5, LeftHanded: 0b, pEffAmp: 0, ImmuneToFire: 0b, OverlayGlowing: 1b, NpcKilledLines: {Lines: []}, TraderMarket: "", ArmorItems: [{}, {}, {}, {}], DisablePitch: 0b, pPhysics: 1b, TransformHasInv: 0b, NpcInteractLines: {Lines: []}, TraderCurrency: {NpcMiscInv: [{Slot: 4b, id: "minecraft:pufferfish", Count: 1b}, {Slot: 18b, id: "fishbonanza:fish_shark", Count: 1b}, {Slot: 19b, id: "fishbonanza:fish_bluefish", Count: 1b}, {Slot: 20b, id: "fishbonanza:fish_sturgeon", Count: 1b}, {Slot: 21b, id: "fishbonanza:fish_frog", Count: 1b}, {Slot: 22b, id: "fishbonanza:fish_koi", Count: 1b}, {Slot: 23b, id: "fishbonanza:fish_loach", Count: 1b}, {Slot: 24b, id: "fishbonanza:fish_black_sea_bass", Count: 1b}, {Slot: 25b, id: "fishbonanza:fish_surgeonfish", Count: 1b}, {Slot: 26b, id: "fishbonanza:fish_cusk", Count: 1b}, {Slot: 27b, id: "fishbonanza:fish_dover_sole", Count: 1b}, {Slot: 28b, id: "fishbonanza:fish_cowcod", Count: 1b}, {Slot: 29b, id: "fishbonanza:fish_oarfish", Count: 1b}, {Slot: 30b, id: "fishbonanza:fish_red_snapper", Count: 1b}, {Slot: 31b, id: "fishbonanza:fish_perch", Count: 1b}, {Slot: 32b, id: "fishbonanza:fish_reticulated_dragonet", Count: 1b}, {Slot: 33b, id: "fishbonanza:fish_redfish", Count: 1b}, {Slot: 34b, id: "fishbonanza:fish_copper_banded_butterflyfish", Count: 1b}, {Slot: 35b, id: "fishbonanza:fish_flatfish", Count: 1b}]}, pSpin: 0b, NpcHurtSound: "minecraft:entity.player.hurt", pTrail: 0, CreatureType: 0, Attributes: [{Base: 0.0d, Name: "forge:step_height_addition"}, {Base: 5.0d, Name: "minecraft:generic.attack_damage"}, {Base: 0.25d, Name: "minecraft:generic.movement_speed"}, {Base: 0.08d, Name: "forge:entity_gravity"}, {Base: 0.5d, Name: "minecraft:generic.flying_speed"}, {Base: 8.0d, Name: "forge:swim_speed"}, {Base: 200.0d, Name: "minecraft:generic.max_health"}, {Base: 32.0d, Name: "minecraft:generic.follow_range"}], Invulnerable: 1b, TransformHasDisplay: 0b, NoFallDamage: 0b, AbsorptionAmount: 0.0f, TransformHasRole: 0b, Name: "Kema Kapitani", SkinColor: 16777215, NpcIdleSound: "", Weapons: [], NPCDialogOptions: [], AggroRange: 8, DirectLOS: 1b, HealthRegen: 30, ForgeCaps: {}, HandDropChances: [0.08500000089406967f, 0.08500000089406967f], NpcModelData: {CustomSkinUrl: "", BodyConfig: {NotShared: 0b, ScaleZ: 1.0f, TransZ: 0.0f, TransY: 0.0f, TransX: 0.0f, ScaleY: 1.0f, ScaleX: 1.0f}, MoveAnimation: 16, Legs2Config: {NotShared: 0b, ScaleZ: 1.0f, TransZ: 0.0f, TransY: 0.0f, TransX: 0.0f, ScaleY: 1.0f, ScaleX: 1.0f}, SimpleRender: 0b, ArmsConfig: {NotShared: 0b, ScaleZ: 1.0f, TransZ: 0.0f, TransY: 0.0f, TransX: 0.0f, ScaleY: 1.0f, ScaleX: 1.0f}, ExtraData: {}, HeadConfig: {NotShared: 0b, ScaleZ: 1.0f, TransZ: 0.0f, TransY: 0.0f, TransX: 0.0f, ScaleY: 1.0f, ScaleX: 1.0f}, LegsConfig: {NotShared: 0b, ScaleZ: 1.0f, TransZ: 0.0f, TransY: 0.0f, TransX: 0.0f, ScaleY: 1.0f, ScaleX: 1.0f}, Arms2Config: {NotShared: 0b, ScaleZ: 1.0f, TransZ: 0.0f, TransY: 0.0f, TransX: 0.0f, ScaleY: 1.0f, ScaleX: 1.0f}, Parts: [], NewParts: [], WingMode: 0, DisplayName: "", Animation: 0, ModelType: 0, LastEdited: 1754567713832L}, VisibleAvailability: {AvailabilityQuestId: -1, AvailabilityScoreboardType: 1, AvailabilityFactionStance: 0, AvailabilityScoreboard2Value: 1, AvailabilityQuest: 0, AvailabilityDialog4: 0, AvailabilityScoreboardObjective: "", AvailabilityDialog3: 0, AvailabilityQuest2: 0, AvailabilityQuest3: 0, AvailabilityScoreboard2Objective: "", AvailabilityQuest4: 0, ModRev: 18, AvailabilityDialog2: 0, AvailabilityDayTime: 0, AvailabilityFaction2Id: -1, AvailabilityScoreboardValue: 1, AvailabilityFaction: 0, AvailabilityDialog: 0, AvailabilityScoreboard2Type: 1, AvailabilityFaction2: 0, AvailabilityFactionId: -1, AvailabilityFaction2Stance: 0, AvailabilityDialogId: -1, AvailabilityQuest4Id: -1, AvailabilityQuest3Id: -1, AvailabilityQuest2Id: -1, AvailabilityDialog2Id: -1, AvailabilityDialog3Id: -1, AvailabilityDialog4Id: -1, AvailabilityMinPlayerLevel: 0}, minDelay: 20, DoorInteract: 2, MoveSpeed: 5, TransformEditingModus: 0b, UsingSkinUrl: 2b, SkinUrl: "https://minecraftch.ru/uploads/skins/skin40338.png", CanSwim: 1b, TraderIgnoreNBT: 0b, GroundSound: "minecraft:block.stone.break", MountControl: 0b, MaxHealth: 200, HideBodyWhenKilled: 1b, AttackSpeed: 30, PotionDuration: 5, maxDelay: 40, ScriptEnabled: 0b, Role: 1, DropChance: [{Integer: 0.5f, Slot: 0}, {Integer: 2.0f, Slot: 1}, {Integer: 60.0f, Slot: 2}, {Integer: 5.0f, Slot: 3}, {Integer: 75.0f, Slot: 4}, {Integer: 100.0f, Slot: 5}, {Integer: 100.0f, Slot: 6}, {Integer: 100.0f, Slot: 7}, {Integer: 100.0f, Slot: 8}], FactionPoints: {DecreaseFaction1Points: 0b, OptionFaction2Points: 100, OptionFactions1: -1, OptionFactions2: -1, OptionFaction1Points: 100, DecreaseFaction2Points: 0b}, pDamage: 4, KilledTime: 0L, AimWhileShooting: 0b, CanPickUpLoot: 0b, AttackOtherFactions: 0b, CanDrown: 0b, pSize: 5, CanSprint: 0b, CanLeap: 0b, TransformIsActive: 0b, ForgeData: {cnpcmarkdata: {marks: []}}, MovingState: 0, MovingPos: 0, PotionAmp: 0, OnAttack: 0, FallFlying: 0b, MaxExp: 1500, OrderedLines: 0b, pGlows: 0b, TransformHasAdvanced: 0b, TransformHasStats: 0b, MovementType: 0, FiringSound: "minecraft:entity.arrow.shoot", ModRev: 18, Accuracy: 60, MinExp: 300, Armor: [], CloakTexture: "", GlowTexture: "", MaxFiringRange: 15, pXlr8: 0b, MarkovGeneratorId: 4, Scripts: [], Health: 200.0f, pStick: 0b, MovingPause: 1b, NpcDeathSound: "minecraft:entity.player.hurt", MovingPathNew: [], FactionID: 10, Title: "<Qora Dengiz>", TotalTicksAlive: 1304855L, ShowName: 0, npcInteracting: 1b, AvoidsWater: 0b, NoLivingAnimation: 0b, SpawnCycle: 0, Tags: ["seatrader"]}
summon customnpcs:customnpc 160.5 108 0.5 {ReturnToStart: 1b, Brain: {memories: {}}, NpcInv: [], BossColor: 0, PotionEffect: 0, Size: 10, stopAndInteract: 1b, Resistances: {Arrow: 1.0f, Explosion: 1.0f, Knockback: 1.0f, Melee: 1.0f}, BossBar: 2b, RespawnTime: 60, NpcAngrySound: "", ReactsToFire: 0b, IgnoreCobweb: 0b, PositionOffsetZ: 5.0f, PositionOffsetY: 5.0f, PositionOffsetX: 5.0f, CanUpdate: 1b, LootMode: 0, TransformHasAI: 0b, AttackStrenght: 8, PersistenceRequired: 0b, id: "customnpcs:customnpc", IsStatue: 0b, MovingPatern: 0, NpcLines: {Lines: []}, DefendFaction: 1b, FireIndirect: 0, NpcVisible: 0, LinkedNpcName: "", NpcScenes: {Scenes: []}, HitSound: "minecraft:entity.arrow.hit", FindShelter: 2, GuardTargets: [], Orientation: 0, ScriptLanguage: "ECMAScript", HandItems: [{}, {}], KnockBack: 1, TransformHasJob: 0b, ArmorDropChances: [0.08500000089406967f, 0.08500000089406967f, 0.08500000089406967f, 0.08500000089406967f], BurnInSun: 0b, StandingState: 0, ShowLayers: 1b, AttackInvisible: 0b, NpcInteractNPCLines: {Lines: []}, WalkingRange: 10, ShotCount: 1, pDur: 2, AttackRange: 1, ActiveRange: 32, NpcKillLines: {Lines: [{Line: "XA-XA-XA, ZAIF!", Song: "", Slot: 0}]}, PotionImmune: 0b, AvoidsSun: 0b, Texture: "customnpcs:textures/entity/humanmale/firesteve.png", NpcJob: 3, BurstCount: 5, NpcAttackLines: {Lines: []}, pSpeed: 10, pArea: 1, pImpact: 0, MoveState: 0, pRender3D: 0b, CombatRegen: 0, NpcsTimers: [], MarkovGender: 0, pEffect: 0, DistanceToMelee: 8, NpcStepSound: "", FireRate: 5, LeftHanded: 0b, pEffAmp: 0, ImmuneToFire: 0b, OverlayGlowing: 1b, NpcKilledLines: {Lines: [{Line: "Sen haqiqiy baliqchisan... Xarita seniki! (Saytda sharh qoldirishni unutma!)", Song: "", Slot: 0}]}, ArmorItems: [{}, {}, {}, {}], DisablePitch: 0b, pPhysics: 0b, TransformHasInv: 0b, NpcInteractLines: {Lines: [{Line: "Sen haqiqatan ham meni shu kiyimda yengmoqchimisan?", Song: "", Slot: 0}]}, pSpin: 0b, NpcHurtSound: "minecraft:entity.player.hurt", pTrail: 0, CreatureType: 0, Attributes: [{Base: 0.0d, Name: "forge:step_height_addition"}, {Base: 5.0d, Name: "minecraft:generic.attack_damage"}, {Base: 0.20000000298023224d, Name: "minecraft:generic.movement_speed"}, {Base: 0.08d, Name: "forge:entity_gravity"}, {Base: 0.4000000059604645d, Name: "minecraft:generic.flying_speed"}, {Base: 6.400000095367432d, Name: "forge:swim_speed"}, {Base: 400.0d, Name: "minecraft:generic.max_health"}, {Base: 0.0d, Name: "minecraft:generic.armor"}, {Base: 0.0d, Name: "minecraft:generic.knockback_resistance"}, {Base: 0.0d, Name: "minecraft:generic.armor_toughness"}, {Base: 32.0d, Name: "minecraft:generic.follow_range"}], Invulnerable: 0b, TransformHasDisplay: 0b, NoFallDamage: 0b, AbsorptionAmount: 0.0f, TransformHasRole: 0b, Name: "DENGIZ QIROLI", SkinColor: 16777215, NpcIdleSound: "", Weapons: [{Slot: 0b, id: "minecraft:netherite_sword", Count: 1b, tag: {Damage: 0}}], NPCDialogOptions: [], AggroRange: 40, DirectLOS: 1b, HealthRegen: 10, ForgeCaps: {}, HandDropChances: [0.08500000089406967f, 0.08500000089406967f], NpcModelData: {CustomSkinUrl: "", BodyConfig: {NotShared: 0b, ScaleZ: 1.0f, TransZ: 0.0f, TransY: 0.06929348409175873f, TransX: 0.0f, ScaleY: 1.0f, ScaleX: 1.0f}, MoveAnimation: 16, Legs2Config: {NotShared: 0b, ScaleZ: 0.8369565010070801f, TransZ: -0.0010190218454226851f, TransY: 0.06929348409175873f, TransX: 0.009619566611945629f, ScaleY: 0.907608687877655f, ScaleX: 0.91847825050354f}, SimpleRender: 0b, ArmsConfig: {NotShared: 0b, ScaleZ: 1.5f, TransZ: 0.0f, TransY: 0.09578804671764374f, TransX: 0.008831523358821869f, ScaleY: 1.21195650100708f, ScaleX: 1.14130437374115f}, ExtraData: {}, HeadConfig: {NotShared: 0b, ScaleZ: 1.0f, TransZ: 0.0f, TransY: 0.06929348409175873f, TransX: 0.0f, ScaleY: 1.0f, ScaleX: 1.0271739959716797f}, LegsConfig: {NotShared: 0b, ScaleZ: 0.8369565010070801f, TransZ: -0.0010190218454226851f, TransY: 0.06929348409175873f, TransX: -0.009619566611945629f, ScaleY: 0.907608687877655f, ScaleX: 0.91847825050354f}, Arms2Config: {NotShared: 0b, ScaleZ: 1.5f, TransZ: 0.0f, TransY: 0.09578804671764374f, TransX: -0.008831523358821869f, ScaleY: 1.21195650100708f, ScaleX: 1.14130437374115f}, Parts: [], NewParts: [], WingMode: 0, DisplayName: "", Animation: 0, ModelType: 0, LastEdited: 1754523040485L}, VisibleAvailability: {AvailabilityQuestId: -1, AvailabilityScoreboardType: 1, AvailabilityFactionStance: 0, AvailabilityScoreboard2Value: 1, AvailabilityQuest: 0, AvailabilityDialog4: 0, AvailabilityScoreboardObjective: "", AvailabilityDialog3: 0, AvailabilityQuest2: 0, AvailabilityQuest3: 0, AvailabilityScoreboard2Objective: "", AvailabilityQuest4: 0, ModRev: 18, AvailabilityDialog2: 0, AvailabilityDayTime: 0, AvailabilityFaction2Id: -1, AvailabilityScoreboardValue: 1, AvailabilityFaction: 0, AvailabilityDialog: 0, AvailabilityScoreboard2Type: 1, AvailabilityFaction2: 0, AvailabilityFactionId: -1, AvailabilityFaction2Stance: 0, AvailabilityDialogId: -1, AvailabilityQuest4Id: -1, AvailabilityQuest3Id: -1, AvailabilityQuest2Id: -1, AvailabilityDialog2Id: -1, AvailabilityDialog3Id: -1, AvailabilityDialog4Id: -1, AvailabilityMinPlayerLevel: 0}, minDelay: 8, DoorInteract: 2, MoveSpeed: 4, TransformEditingModus: 0b, UsingSkinUrl: 0b, SkinUrl: "", CanSwim: 1b, GroundSound: "minecraft:block.stone.break", MountControl: 0b, MaxHealth: 800, HideBodyWhenKilled: 1b, AttackSpeed: 50, PotionDuration: 2, maxDelay: 10, ScriptEnabled: 0b, Role: 0, DropChance: [{Integer: 100.0f, Slot: 0}, {Integer: 100.0f, Slot: 1}, {Integer: 100.0f, Slot: 2}, {Integer: 100.0f, Slot: 3}, {Integer: 100.0f, Slot: 4}, {Integer: 100.0f, Slot: 5}, {Integer: 100.0f, Slot: 6}, {Integer: 100.0f, Slot: 7}, {Integer: 100.0f, Slot: 8}], FactionPoints: {DecreaseFaction1Points: 0b, OptionFaction2Points: 100, OptionFactions1: 2, OptionFactions2: -1, OptionFaction1Points: 10, DecreaseFaction2Points: 0b}, pDamage: 0, KilledTime: 0L, AimWhileShooting: 0b, CanPickUpLoot: 0b, AttackOtherFactions: 0b, CanDrown: 1b, pSize: 5, CanSprint: 0b, CanLeap: 1b, TransformIsActive: 0b, ForgeData: {cnpcmarkdata: {marks: [{availability: {AvailabilityQuestId: -1, AvailabilityScoreboardType: 1, AvailabilityFactionStance: 2, AvailabilityScoreboard2Value: 1, AvailabilityQuest: 0, AvailabilityDialog4: 0, AvailabilityScoreboardObjective: "", AvailabilityDialog3: 0, AvailabilityQuest2: 0, AvailabilityQuest3: 0, AvailabilityScoreboard2Objective: "", AvailabilityQuest4: 0, ModRev: 18, AvailabilityDialog2: 0, AvailabilityDayTime: 0, AvailabilityFaction2Id: 2, AvailabilityScoreboardValue: 1, AvailabilityFaction: 1, AvailabilityDialog: 0, AvailabilityScoreboard2Type: 1, AvailabilityFaction2: 1, AvailabilityFactionId: 2, AvailabilityFaction2Stance: 2, AvailabilityDialogId: -1, AvailabilityQuest4Id: -1, AvailabilityQuest3Id: -1, AvailabilityQuest2Id: -1, AvailabilityDialog2Id: -1, AvailabilityDialog3Id: -1, AvailabilityDialog4Id: -1, AvailabilityMinPlayerLevel: 0}, color: 16453382, type: 4}]}}, MovingState: 0, MovingPos: 0, PotionAmp: 3, OnAttack: 0, FallFlying: 0b, MaxExp: 1333, OrderedLines: 0b, pGlows: 0b, TransformHasAdvanced: 0b, TransformHasStats: 0b, MovementType: 0, FiringSound: "minecraft:entity.arrow.shoot", ModRev: 18, Accuracy: 100, MinExp: 780, Armor: [{Slot: 0b, id: "minecraft:netherite_helmet", Count: 1b, tag: {Damage: 0}}, {Slot: 3b, id: "minecraft:netherite_boots", Count: 1b, tag: {Damage: 0}}], CloakTexture: "", GlowTexture: "", MaxFiringRange: 50, pXlr8: 0b, MarkovGeneratorId: 5, Scripts: [], Health: 800.0f, pStick: 0b, MovingPause: 1b, NpcDeathSound: "minecraft:entity.player.hurt", MovingPathNew: [], FactionID: 2, Title: "<Qora Dengiz>", TotalTicksAlive: 1414916L, ShowName: 0, npcInteracting: 1b, AvoidsWater: 0b, NoLivingAnimation: 0b, SpawnCycle: 0, Tags: ["boss2"]}
forceload remove all
scoreboard players set #sea_ready stream_data 1
function stream:boats_spawn
