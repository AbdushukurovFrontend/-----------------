execute if score #c stream_data matches 0 run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 2 1.5
execute if score #c stream_data matches 10 run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 2 1.5
execute if score #c stream_data matches 20 run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 2 1.5
execute if score #c stream_data matches 30 run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 2 1.5
title @s actionbar {"text":"ORQANGDA!","color":"dark_red","bold":true}
