execute store result score #mobs stream_data if entity @e[tag=wave_mob]
execute store result bossbar stream:wave value run scoreboard players get #mobs stream_data
execute store result bossbar stream:wave max run scoreboard players get #wmax stream_data
bossbar set stream:wave players @a[tag=!in_lobby]
bossbar set stream:wave name [{"text":"KECHA ","color":"red","bold":true},{"score":{"name":"#wave","objective":"stream_data"},"color":"yellow","bold":true},{"text":": mob qoldi ","color":"red"},{"score":{"name":"#mobs","objective":"stream_data"},"color":"yellow","bold":true}]
execute if score #mobs stream_data matches 0 run function stream:wave_clear
