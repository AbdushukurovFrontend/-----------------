bossbar set stream:boss2 visible false
execute if score #boss2saw stream_data matches 1 run function stream:boss2_down
