forceload add 48 0 63 15
schedule function stream:boss1_ensure2 40t
