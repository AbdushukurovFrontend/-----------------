bossbar set stream:boss visible true
execute unless entity @s[tag=boss_v] run function stream:boss_pick
execute store result bossbar stream:boss value run data get entity @s Health
execute store result score #bosshp stream_data run data get entity @s Health
execute if score #bosshp stream_data matches ..200 unless entity @s[tag=boss_p2] run function stream:boss_p2
execute if score #bosshp stream_data matches ..100 unless entity @s[tag=boss_p3] run function stream:boss_p3
scoreboard players set #bosssaw stream_data 1
execute if score #stage stream_data matches ..2 run function stream:stage3
