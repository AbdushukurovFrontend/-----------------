kill @e[tag=blackmarket]
tellraw @a[tag=!in_lobby] {"text":"Qora Bozor yopildi.","color":"dark_purple"}
