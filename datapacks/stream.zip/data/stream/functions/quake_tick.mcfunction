scoreboard players add #bt stream_data 1
execute if score #bt stream_data matches 10.. run function stream:quake_warn
