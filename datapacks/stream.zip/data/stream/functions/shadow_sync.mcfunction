scoreboard players operation #me stream_data = @s uid
scoreboard players set #found stream_data 0
execute as @e[type=armor_stand,tag=shadow] if score @s uid = #me stream_data run scoreboard players set #found stream_data 1
execute as @e[type=armor_stand,tag=shadow] if score @s uid = #me stream_data run tp @s ~ ~ ~
execute if score #found stream_data matches 0 run summon armor_stand ~ ~ ~ {Tags:["shadow","shadow_new"],Invisible:1b,Marker:1b,NoGravity:1b,Silent:1b}
execute if score #found stream_data matches 0 run scoreboard players operation @e[tag=shadow_new,limit=1] uid = #me stream_data
tag @e[tag=shadow_new] remove shadow_new
