execute as @a unless score @s uid matches 1.. run function stream:assign_uid
scoreboard players enable @a yordam
execute as @a[scores={yordam=1..}] run function stream:help
execute if score #active stream_data matches 1 as @a[tag=!downed,tag=!in_lobby,gamemode=!spectator,gamemode=!creative] at @s run function stream:shadow_sync
execute as @a[scores={stream_kills=1..}] run function stream:on_kill
tag @a remove reviving
execute as @a[tag=!downed,gamemode=!spectator,nbt={SelectedItem:{tag:{aptechka:1b}}}] at @s if entity @e[tag=body,distance=..3] run tag @s add reviving
execute as @a[tag=reviving] at @s run function stream:reviving
scoreboard players set @a[tag=!reviving] rev_t 0
execute as @a[x=50,y=100,z=-8,dx=20,dy=20,dz=16] run clear @s minecraft:red_shulker_box{Tags:["tp"]}
execute unless score #active stream_data matches 1 as @a[tag=downed] run function stream:undown
