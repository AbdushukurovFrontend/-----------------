scoreboard players set #stage stream_data 5
function stream:goal_update
execute if entity @e[tag=body] run function stream:mass_revive
