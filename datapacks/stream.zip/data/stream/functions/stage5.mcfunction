scoreboard players set #stage stream_data 5
execute if entity @e[tag=body] run function stream:mass_revive
function stream:goal_update
