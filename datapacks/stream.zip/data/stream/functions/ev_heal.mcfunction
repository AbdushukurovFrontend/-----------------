title @a[tag=!in_lobby] times 10 60 15
title @a[tag=!in_lobby] subtitle {"text":"Jon tiklanadi va qalqon beriladi","color":"gray"}
title @a[tag=!in_lobby] title {"text":"SHIFO!","color":"light_purple","bold":true}
effect give @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator] minecraft:regeneration 15 1 false
effect give @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator] minecraft:absorption 60 2 false
