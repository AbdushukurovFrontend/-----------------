scoreboard players set #ticks stream_data 0
scoreboard players add #sec stream_data 1
function stream:calc
title @a[tag=!in_lobby] actionbar [{"text":"Vaqt: ","color":"gray"},{"score":{"name":"#min","objective":"stream_data"},"color":"yellow","bold":true},{"text":":","color":"yellow","bold":true},{"score":{"name":"#s10","objective":"stream_data"},"color":"yellow","bold":true},{"score":{"name":"#s1","objective":"stream_data"},"color":"yellow","bold":true},{"text":"  |  Jonlar: ","color":"gray"},{"score":{"name":"#lives","objective":"stream_data"},"color":"red","bold":true}]
function stream:evt_tick
function stream:night_tick
function stream:stage_tick
execute as @e[type=customnpcs:customnpc,nbt={Name:"ZINDON TITANI"},x=45,y=65,z=4,distance=..35] at @s run function stream:boss_sec
