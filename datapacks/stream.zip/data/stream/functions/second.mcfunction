scoreboard players set #ticks stream_data 0
scoreboard players add #sec stream_data 1
function stream:calc
title @a[tag=!in_lobby] actionbar [{"text":"⌛ ","color":"gray"},{"score":{"name":"#min","objective":"stream_data"},"color":"yellow"},{"text":":","color":"yellow"},{"score":{"name":"#s10","objective":"stream_data"},"color":"yellow"},{"score":{"name":"#s1","objective":"stream_data"},"color":"yellow"},{"text":"    ♥ ","color":"red"},{"score":{"name":"#lives","objective":"stream_data"},"color":"white"},{"text":"    ⚡ ","color":"gold"},{"score":{"name":"#em","objective":"stream_data"},"color":"white"},{"text":":","color":"white"},{"score":{"name":"#e10","objective":"stream_data"},"color":"white"},{"score":{"name":"#e1","objective":"stream_data"},"color":"white"}]
function stream:evt_tick
function stream:night_tick
function stream:stage_tick
execute as @e[type=customnpcs:customnpc,nbt={Name:"ZINDON TITANI"},x=25,y=50,z=-15,dx=45,dy=21,dz=40] at @s run function stream:boss_sec
