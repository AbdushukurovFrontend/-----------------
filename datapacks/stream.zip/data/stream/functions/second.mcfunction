scoreboard players set #ticks stream_data 0
scoreboard players add #sec stream_data 1
function stream:calc
title @a actionbar [{"text":"Vaqt: ","color":"gray"},{"score":{"name":"#min","objective":"stream_data"},"color":"yellow","bold":true},{"text":":","color":"yellow","bold":true},{"score":{"name":"#s10","objective":"stream_data"},"color":"yellow","bold":true},{"score":{"name":"#s1","objective":"stream_data"},"color":"yellow","bold":true}]
