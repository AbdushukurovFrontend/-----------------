gamemode creative @s
tp @s 56 107 0
tellraw @s {"text":"[Sinov] Iskala: X 56, Y 107, Z 0","color":"green"}
