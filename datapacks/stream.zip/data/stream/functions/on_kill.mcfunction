scoreboard players operation #killacc stream_data += @s stream_kills
scoreboard players reset @s stream_kills
execute if score #killacc stream_data matches 8.. at @s run function stream:drop_kit
