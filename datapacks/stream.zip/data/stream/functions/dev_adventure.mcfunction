gamemode adventure @s
tellraw @s {"text":"[Sinov] Adventure rejimiga qaytdingiz.","color":"yellow"}
