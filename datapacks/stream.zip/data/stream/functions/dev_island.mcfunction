gamemode creative @s
tp @s 122 108 0
tellraw @s {"text":"[Sinov] Qora orol: X 122, Y 108, Z 0 (qal'a darvozasi X 142, markaz X 160)","color":"green"}
