scoreboard players set #stage stream_data 6
function stream:goal_update
