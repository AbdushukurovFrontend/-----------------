bossbar set stream:boss visible false
kill @e[tag=boss_minion]
execute if score #bosssaw stream_data matches 1 run function stream:boss_down
