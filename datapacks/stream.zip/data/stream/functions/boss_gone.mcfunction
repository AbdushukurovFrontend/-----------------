bossbar set stream:boss visible false
kill @e[tag=boss_minion]
