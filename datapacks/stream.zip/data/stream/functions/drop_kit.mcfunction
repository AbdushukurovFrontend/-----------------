scoreboard players remove #killacc stream_data 8
summon item ~ ~ ~ {Age:-32768s,PickupDelay:0s,Glowing:1b,Tags:["kit","global.ignore"],Item:{id:"minecraft:nether_star",Count:1b,tag:{aptechka:1b,display:{Name:'{"text":"Aptechka","color":"red","bold":true,"italic":false}',Lore:['{"text":"Sherigingiz tanasi yonida 3 soniya ushlab turing","color":"gray","italic":false}']}}}}
tellraw @a[tag=!in_lobby] {"text":"Aptechka tushdi! 8 ta mob yengildi.","color":"green"}
execute if score #killacc stream_data matches 8.. run function stream:drop_kit
