scoreboard players set #waveactive stream_data 0
bossbar set stream:wave visible false
give @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator] minecraft:golden_apple 1
playsound minecraft:ui.toast.challenge_complete master @a[tag=!in_lobby] ~ ~ ~ 1 1
title @a[tag=!in_lobby] times 10 60 15
title @a[tag=!in_lobby] subtitle {"text":"Mukofot: oltin olma va kundalik sahifasi","color":"gray"}
title @a[tag=!in_lobby] title {"text":"KECHA YENGILDI!","color":"gold","bold":true}
execute if score #wave stream_data matches 1 run function stream:diary1
execute if score #wave stream_data matches 2 run function stream:diary2
execute if score #wave stream_data matches 3 run function stream:diary3
execute if score #wave stream_data matches 4 run function stream:diary4
execute if score #wave stream_data matches 5 run function stream:diary5
