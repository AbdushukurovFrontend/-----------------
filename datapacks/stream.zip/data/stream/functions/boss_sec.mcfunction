execute if entity @s[tag=boss_quake] run function stream:quake_tick
execute if entity @s[tag=boss_bolt] run function stream:bolt_tick
execute if entity @s[tag=boss_ice] run function stream:ice_tick
