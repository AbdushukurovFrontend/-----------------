bossbar set stream:boss2 players @a[x=160,y=108,z=0,distance=..60]
execute as @e[type=customnpcs:customnpc,tag=boss2,x=160,y=108,z=0,distance=..60] at @s run function stream:boss2_tick
execute unless entity @e[type=customnpcs:customnpc,tag=boss2,x=160,y=108,z=0,distance=..60] run function stream:boss2_gone
