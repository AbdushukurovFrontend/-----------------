tag @s add stalker_calm
kill @e[type=item,nbt={Item:{id:"fishbonanza:fish_koi"}},distance=..3,limit=1]
effect give @s minecraft:slowness infinite 255 true
effect clear @s minecraft:speed
execute as @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator] run give @s minecraft:totem_of_undying 1
playsound minecraft:ui.toast.challenge_complete master @a[tag=!in_lobby] ~ ~ ~ 1 0.8
title @a[tag=!in_lobby] times 10 60 15
title @a[tag=!in_lobby] subtitle {"text":"Oltin Koi egasiga qaytdi. La'nat tugadi.","color":"gray"}
title @a[tag=!in_lobby] title {"text":"SOBIR TINCHLANDI","color":"gold","bold":true}
tellraw @a[tag=!in_lobby] [{"text":"Sobir: ","color":"gold","bold":true},{"text":"Rahmat... Nihoyat uyga qaytaman.","color":"white","italic":true}]
