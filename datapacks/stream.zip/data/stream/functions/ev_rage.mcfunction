title @a[tag=!in_lobby] times 5 35 10
title @a[tag=!in_lobby] subtitle {"text":"Stalker 40 soniya tez yuradi","color":"gray"}
title @a[tag=!in_lobby] title {"text":"STALKER G'AZABI!","color":"dark_red","bold":true}
effect give @e[type=customnpcs:customnpc,tag=stalker,tag=!stalker_calm] minecraft:speed 40 2 true
playsound minecraft:entity.warden.roar master @a[tag=!in_lobby] ~ ~ ~ 2 1
