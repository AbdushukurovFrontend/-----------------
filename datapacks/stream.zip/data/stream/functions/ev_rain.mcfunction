title @a[tag=!in_lobby] times 10 60 15
title @a[tag=!in_lobby] subtitle {"text":"Osmondan baliq yog'ilyapti - yig'ib ol!","color":"gray"}
title @a[tag=!in_lobby] title {"text":"BALIQ YOMG'IRI!","color":"aqua","bold":true}
playsound minecraft:weather.rain master @a[tag=!in_lobby] ~ ~ ~ 1 1
execute at @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator] run summon item ~3 ~10 ~ {Item:{id:"minecraft:cod",Count:8b}}
execute at @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator] run summon item ~-3 ~10 ~ {Item:{id:"minecraft:salmon",Count:6b}}
execute at @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator] run summon item ~ ~10 ~3 {Item:{id:"minecraft:tropical_fish",Count:3b}}
execute at @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator] run summon item ~ ~10 ~-3 {Item:{id:"fishbonanza:fish_goldfish",Count:1b}}
execute at @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator] run summon item ~2 ~12 ~2 {Item:{id:"fishbonanza:fish_betta",Count:1b}}
