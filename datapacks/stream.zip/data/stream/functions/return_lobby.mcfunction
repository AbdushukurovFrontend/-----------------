execute if score #active stream_data matches 2 run function stream:return_lobby2
