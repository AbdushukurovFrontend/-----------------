scoreboard players set #night stream_data 0
scoreboard players set #waveactive stream_data 0
kill @e[tag=wave_mob]
kill @e[tag=raid_mob]
bossbar set stream:wave visible false
tellraw @a[tag=!in_lobby] {"text":"Tong otdi! Dushmanlar yo'qoldi.","color":"yellow"}
