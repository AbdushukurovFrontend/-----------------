execute unless score #night stream_data matches 1 run function stream:ev_rain
execute if score #night stream_data matches 1 run function stream:bm_open
