scoreboard players add #deaths stream_data 1
scoreboard players reset @s stream_death
function stream:calc
tellraw @a [{"selector":"@s","color":"yellow"},{"text":" halok bo'ldi. Jami o'limlar: ","color":"red"},{"score":{"name":"#deaths","objective":"stream_data"},"color":"yellow","bold":true}]
