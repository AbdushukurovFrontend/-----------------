scoreboard players reset @s stream_death
execute if score #active stream_data matches 1 unless entity @s[tag=in_lobby] run function stream:died_run
