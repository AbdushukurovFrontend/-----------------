scoreboard players add #deaths stream_data 1
scoreboard players set #active stream_data 0
scoreboard players reset @s stream_death
function stream:calc
tellraw @a [{"text":"O'limlar soni: ","color":"red"},{"score":{"name":"#deaths","objective":"stream_data"},"color":"yellow","bold":true}]
