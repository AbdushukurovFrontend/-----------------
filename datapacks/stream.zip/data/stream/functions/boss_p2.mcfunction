tag @s add boss_p2
tellraw @a[x=45,y=65,z=4,distance=..35] [{"text":"ZINDON TITANI ","color":"dark_red","bold":true},{"text":"g'azablandi! Yordamchilarini chaqirdi!","color":"red"}]
title @a[x=45,y=65,z=4,distance=..35] times 5 40 10
title @a[x=45,y=65,z=4,distance=..35] subtitle {"text":"Jonining yarmi ketdi","color":"gray"}
title @a[x=45,y=65,z=4,distance=..35] title {"text":"2-BOSQICH","color":"dark_red","bold":true}
execute as @a[x=45,y=65,z=4,distance=..35] at @s run playsound minecraft:entity.ender_dragon.growl hostile @s ~ ~ ~ 3 0.8
execute at @a[x=45,y=65,z=4,distance=..35] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=45,y=65,z=4,distance=..35] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=45,y=65,z=4,distance=..35] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
