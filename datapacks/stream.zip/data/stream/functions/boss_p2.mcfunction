tag @s add boss_p2
tellraw @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] [{"text":"ZINDON TITANI ","color":"dark_red","bold":true},{"text":"g'azablandi! Yordamchilarini chaqirdi!","color":"red"}]
title @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] times 5 40 10
title @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] subtitle {"text":"Jonining yarmi ketdi","color":"gray"}
title @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] title {"text":"2-BOSQICH","color":"dark_red","bold":true}
execute as @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] at @s run playsound minecraft:entity.ender_dragon.growl hostile @s ~ ~ ~ 3 0.8
execute at @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40,gamemode=!spectator] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40,gamemode=!spectator] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
execute at @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40,gamemode=!spectator] run summon husk ~ ~ ~ {Tags:["boss_minion"],PersistenceRequired:1b}
