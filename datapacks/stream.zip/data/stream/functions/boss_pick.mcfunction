tag @s add boss_v
scoreboard players set #bt stream_data 0
execute store result score #r stream_data run time query gametime
scoreboard players operation #r stream_data %= #3 stream_data
execute if score #r stream_data matches 0 run tag @s add boss_quake
execute if score #r stream_data matches 0 run bossbar set stream:boss name {"text":"ZINDON TITANI - ZILZILA","color":"dark_red","bold":true}
execute if score #r stream_data matches 0 run tellraw @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] [{"text":"Bu safar Boss: ","color":"gray"},{"text":"ZILZILA TITANI. ","color":"dark_red","bold":true},{"text":"Har 10 soniyada yer qimirlaydi: sakrab turing!","color":"red"}]
execute if score #r stream_data matches 1 run tag @s add boss_bolt
execute if score #r stream_data matches 1 run bossbar set stream:boss name {"text":"ZINDON TITANI - CHAQMOQ","color":"dark_red","bold":true}
execute if score #r stream_data matches 1 run tellraw @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] [{"text":"Bu safar Boss: ","color":"gray"},{"text":"CHAQMOQ TITANI. ","color":"dark_red","bold":true},{"text":"Chaqmoqlar yaqiningizga tushadi: to'xtab turmang!","color":"red"}]
execute if score #r stream_data matches 2 run tag @s add boss_ice
execute if score #r stream_data matches 2 run bossbar set stream:boss name {"text":"ZINDON TITANI - MUZ","color":"dark_red","bold":true}
execute if score #r stream_data matches 2 run tellraw @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] [{"text":"Bu safar Boss: ","color":"gray"},{"text":"MUZ TITANI. ","color":"dark_red","bold":true},{"text":"Bossga yaqin kelsangiz sekinlashasiz!","color":"red"}]
