scoreboard players add #deaths stream_data 1
tag @s add dying
execute store result score #others stream_data if entity @a[tag=!dying,tag=!downed,tag=!in_lobby,gamemode=!creative,gamemode=!spectator]
execute if score #others stream_data matches 0 run function stream:team_wipe
execute if score #others stream_data matches 1.. run function stream:go_down
tag @s remove dying
function stream:calc
