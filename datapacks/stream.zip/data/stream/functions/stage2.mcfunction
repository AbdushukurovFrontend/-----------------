scoreboard players set #stage stream_data 2
function stream:guide_give
