bossbar set stream:boss players @a[x=45,y=65,z=4,distance=..35]
execute as @e[type=customnpcs:customnpc,nbt={Name:"ZINDON TITANI"},x=45,y=65,z=4,distance=..35] at @s run function stream:boss_tick
execute unless entity @e[type=customnpcs:customnpc,nbt={Name:"ZINDON TITANI"},x=45,y=65,z=4,distance=..35] run function stream:boss_gone
