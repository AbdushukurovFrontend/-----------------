bossbar set stream:boss players @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40]
execute as @e[type=customnpcs:customnpc,nbt={Name:"ZINDON TITANI"},x=25,y=50,z=-15,dx=45,dy=21,dz=40] at @s run function stream:boss_tick
execute unless entity @e[type=customnpcs:customnpc,nbt={Name:"ZINDON TITANI"},x=25,y=50,z=-15,dx=45,dy=21,dz=40] run function stream:boss_gone
