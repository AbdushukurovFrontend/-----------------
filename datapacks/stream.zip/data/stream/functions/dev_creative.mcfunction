gamemode creative @s
tellraw @s {"text":"[Sinov] Creative rejimi yoqildi.","color":"green"}
