scoreboard players add #bt stream_data 1
execute if score #bt stream_data matches 6.. run function stream:bolt_hit
