execute if score #stage stream_data matches 1 run bossbar set stream:goal name [{"text":"MAQSAD: ","color":"yellow","bold":true},{"text":"Baliq tuting, savdogardan jihoz oling, keyin BOSSGA TELEPORT (X 18, Z -22)","color":"white"}]
execute if score #stage stream_data matches 2 run bossbar set stream:goal name [{"text":"MAQSAD: ","color":"yellow","bold":true},{"text":"Jihozlaning va BOSSGA TELEPORT lavhasiga boring (X 18, Z -22)","color":"white"}]
execute if score #stage stream_data matches 3 run bossbar set stream:goal name [{"text":"MAQSAD: ","color":"yellow","bold":true},{"text":"ZINDON TITANI ni yenging!","color":"white"}]
execute if score #stage stream_data matches 4 run bossbar set stream:goal name [{"text":"MAQSAD: ","color":"yellow","bold":true},{"text":"Boss tushirgan qizil shulkerni QO'LGA OLING (Qora Dengiz portali)","color":"white"}]
execute if score #stage stream_data matches 5 run bossbar set stream:goal name [{"text":"MAQSAD: ","color":"yellow","bold":true},{"text":"Qayiqqa o'ting va sharqqa suzing (chiroqlar yo'l ko'rsatadi)","color":"white"}]
execute if score #stage stream_data matches 6 run bossbar set stream:goal name [{"text":"MAQSAD: ","color":"yellow","bold":true},{"text":"Qal'a markazidagi DENGIZ QIROLI ni yenging!","color":"white"}]
execute if score #stage stream_data matches 7 run bossbar set stream:goal name [{"text":"MAQSAD: ","color":"yellow","bold":true},{"text":"Siz xaritani yakunladingiz!","color":"white"}]
bossbar set stream:goal players @a[tag=!in_lobby]
bossbar set stream:goal visible true
