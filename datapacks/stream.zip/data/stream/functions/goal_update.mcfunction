function stream:guide_give
title @a[tag=!in_lobby] times 5 40 10
title @a[tag=!in_lobby] subtitle {"text":"Yangi maqsad: qo'llanmani oching","color":"yellow"}
title @a[tag=!in_lobby] title {"text":""}
execute as @a[tag=!in_lobby] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.5
