# ---------- TAYMER VA OLIMLAR ----------
execute as @a[scores={stream_death=1..}] run function stream:died
execute if score #active stream_data matches 0 if entity @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator] run function stream:start
execute if score #active stream_data matches 1 if entity @a[x=14,y=68,z=39,dx=6,dy=6,dz=6] run function stream:finish
execute if entity @a[x=10,y=70,z=-20,dx=25,dy=12,dz=40] run scoreboard players set #active stream_data 0
execute if score #active stream_data matches 1 run scoreboard players add #ticks stream_data 1
execute if score #ticks stream_data matches 20.. run function stream:second

# ---------- STALKER OGOHLANTIRISHI ----------
scoreboard players add #c stream_data 1
execute if score #c stream_data matches 40.. run scoreboard players set #c stream_data 0
execute as @e[type=customnpcs:customnpc,tag=stalker] at @s as @a[gamemode=!creative,gamemode=!spectator,distance=..20] at @s run function stream:warn20

# ---------- BOSS ----------
execute if entity @a[x=45,y=65,z=4,distance=..35] run function stream:boss
execute unless entity @a[x=45,y=65,z=4,distance=..35] run bossbar set stream:boss visible false
