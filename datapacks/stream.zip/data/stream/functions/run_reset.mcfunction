scoreboard players set #active stream_data 0
scoreboard players set #wave stream_data 0
scoreboard players set #night stream_data 0
scoreboard players set #waveactive stream_data 0
scoreboard players set #evt stream_data 180
scoreboard players set #bm stream_data 0
kill @e[tag=wave_mob]
kill @e[tag=raid_mob]
kill @e[tag=blackmarket]
kill @e[tag=boss_minion]
effect clear @e[type=customnpcs:customnpc,tag=stalker]
tag @e[type=customnpcs:customnpc,tag=stalker] remove stalker_calm
bossbar set stream:event visible false
bossbar set stream:wave visible false
function stream:calc
