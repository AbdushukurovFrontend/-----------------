scoreboard players set #active stream_data 0
scoreboard players set #wave stream_data 0
scoreboard players set #night stream_data 0
scoreboard players set #waveactive stream_data 0
scoreboard players set #evt stream_data 180
scoreboard players set #bm stream_data 0
kill @e[tag=wave_mob]
kill @e[tag=raid_mob]
kill @e[tag=blackmarket]
kill @e[tag=boss_minion]
effect clear @e[type=customnpcs:customnpc,tag=stalker]
tag @e[type=customnpcs:customnpc,tag=stalker] remove stalker_calm
bossbar set stream:event visible false
bossbar set stream:wave visible false
function stream:calc
scoreboard players set #lives stream_data 5
scoreboard players set #stage stream_data 0
scoreboard players set #killacc stream_data 0
scoreboard players set #bosssaw stream_data 0
scoreboard players set #boss2saw stream_data 0
tag @a remove downed
kill @e[tag=body]
kill @e[tag=shadow]
kill @e[tag=kit]
gamemode adventure @a[gamemode=spectator]
scoreboard players set @a rev_t 0
bossbar set stream:goal visible false
bossbar set stream:boss2 visible false
tp @a[tag=!in_lobby,gamemode=!creative] 22 76 7
