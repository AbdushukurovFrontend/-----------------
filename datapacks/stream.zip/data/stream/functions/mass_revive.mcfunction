tag @a remove downed
gamemode adventure @a[gamemode=spectator]
tp @a[tag=!in_lobby,gamemode=!creative] 56 107 0
kill @e[tag=body]
tellraw @a {"text":"Yangi hudud: barcha sheriklar tirildi!","color":"green"}
