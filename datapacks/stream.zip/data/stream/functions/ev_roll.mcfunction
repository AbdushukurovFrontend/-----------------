scoreboard players set #evt stream_data 180
execute store result score #r stream_data run time query gametime
scoreboard players operation #r stream_data += #sec stream_data
scoreboard players operation #r stream_data %= #8 stream_data
execute if score #r stream_data matches 0 run function stream:ev_rain
execute if score #r stream_data matches 1 run function stream:ev_luck
execute if score #r stream_data matches 2 run function stream:ev_heal
execute if score #r stream_data matches 3 run function stream:ev_bm
execute if score #r stream_data matches 4 run function stream:ev_fog
execute if score #r stream_data matches 5 run function stream:ev_rage
execute if score #r stream_data matches 6 run function stream:ev_raid
execute if score #r stream_data matches 7 run function stream:ev_hunger
