execute store result score #dtn stream_data run time query daytime
scoreboard players operation #m10 stream_data = #c stream_data
scoreboard players operation #m10 stream_data %= #10 stream_data
execute if score #dtn stream_data matches ..12999 run time add 3
execute if score #dtn stream_data matches 13000.. run time add 4
execute if score #m10 stream_data matches ..5 run time add 1
