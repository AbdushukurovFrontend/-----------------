execute run summon husk ~14 ~ ~0 {Tags:["wave_mob"],PersistenceRequired:1b}
execute run summon husk ~-14 ~ ~0 {Tags:["wave_mob"],PersistenceRequired:1b}
execute run summon husk ~0 ~ ~14 {Tags:["wave_mob"],PersistenceRequired:1b}
execute run summon husk ~0 ~ ~-14 {Tags:["wave_mob"],PersistenceRequired:1b}
execute if score #wave stream_data matches 2.. run summon husk ~10 ~ ~10 {Tags:["wave_mob"],PersistenceRequired:1b}
execute if score #wave stream_data matches 2.. run summon husk ~-10 ~ ~-10 {Tags:["wave_mob"],PersistenceRequired:1b}
execute if score #wave stream_data matches 2.. run summon stray ~-10 ~ ~10 {Tags:["wave_mob"],PersistenceRequired:1b}
execute if score #wave stream_data matches 2.. run summon stray ~10 ~ ~-10 {Tags:["wave_mob"],PersistenceRequired:1b}
execute if score #wave stream_data matches 3.. run summon creeper ~16 ~ ~6 {Tags:["wave_mob"],PersistenceRequired:1b}
execute if score #wave stream_data matches 3.. run summon creeper ~-16 ~ ~-6 {Tags:["wave_mob"],PersistenceRequired:1b}
execute if score #wave stream_data matches 5.. run summon husk ~6 ~ ~16 {Tags:["wave_mob"],PersistenceRequired:1b}
execute if score #wave stream_data matches 5.. run summon husk ~-6 ~ ~-16 {Tags:["wave_mob"],PersistenceRequired:1b}
execute if score #wave stream_data matches 5.. run summon husk ~16 ~ ~-6 {Tags:["wave_mob"],PersistenceRequired:1b}
execute if score #wave stream_data matches 5.. run summon husk ~-16 ~ ~6 {Tags:["wave_mob"],PersistenceRequired:1b}
execute if score #wave stream_data matches 7.. run summon creeper ~12 ~ ~-12 {Tags:["wave_mob"],PersistenceRequired:1b}
execute if score #wave stream_data matches 7.. run summon creeper ~-12 ~ ~12 {Tags:["wave_mob"],PersistenceRequired:1b}
