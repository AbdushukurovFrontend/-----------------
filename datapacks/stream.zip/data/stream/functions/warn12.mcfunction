effect give @s minecraft:darkness 2 0 true
execute if score #c stream_data matches 0 run playsound minecraft:ambient.cave master @s ~ ~ ~ 1 0.8
execute if score #c stream_data matches 20 run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1.5 1.2
execute if entity @e[type=customnpcs:customnpc,tag=stalker,distance=..6] run function stream:warn6
