scoreboard players set #bt stream_data 0
execute at @a[x=45,y=65,z=4,distance=..35] positioned ~3 ~ ~3 run summon lightning_bolt ~ ~ ~
