scoreboard players set #bt stream_data 0
execute at @a[x=25,y=50,z=-15,dx=45,dy=21,dz=40] positioned ~3 ~ ~3 run summon lightning_bolt ~ ~ ~
