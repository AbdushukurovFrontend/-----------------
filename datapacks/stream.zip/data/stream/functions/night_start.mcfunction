scoreboard players set #night stream_data 1
scoreboard players add #wave stream_data 1
scoreboard players set #waveactive stream_data 1
function stream:calc
execute at @a[x=-500,y=100,z=-500,dx=1000,dy=40,dz=1000,gamemode=!creative,gamemode=!spectator] run function stream:spawn_ring
execute store result score #wmax stream_data if entity @e[tag=wave_mob]
bossbar set stream:wave visible true
bossbar set stream:wave players @a[tag=!in_lobby]
playsound minecraft:entity.wither.spawn master @a[tag=!in_lobby] ~ ~ ~ 1 0.7
title @a[tag=!in_lobby] times 10 60 15
title @a[tag=!in_lobby] subtitle {"text":"Dushmanlar sizni o'rab oldi!","color":"gray"}
title @a[tag=!in_lobby] title {"text":"KECHA BOSHLANDI","color":"red","bold":true}
