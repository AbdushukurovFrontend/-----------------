scoreboard players set #stage stream_data 3
function stream:goal_update
