tp @s ~ ~ ~
gamemode adventure @s
tag @s remove downed
effect give @s minecraft:resistance 5 4 true
effect give @s minecraft:regeneration 10 1 true
playsound minecraft:item.totem.use master @a ~ ~ ~ 1 1
tellraw @a [{"selector":"@s","color":"green","bold":true},{"text":" qayta tirildi!","color":"green"}]
