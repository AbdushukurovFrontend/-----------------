scoreboard players set #active stream_data 2
execute if score #best stream_data matches 0 run scoreboard players operation #best stream_data = #sec stream_data
execute if score #sec stream_data < #best stream_data run scoreboard players operation #best stream_data = #sec stream_data
function stream:calc
bossbar set stream:event visible false
bossbar set stream:wave visible false
kill @e[tag=wave_mob]
kill @e[tag=raid_mob]
kill @e[tag=blackmarket]
title @a times 10 80 20
title @a subtitle [{"text":"Vaqt: ","color":"gray"},{"score":{"name":"#min","objective":"stream_data"},"color":"yellow","bold":true},{"text":":","color":"yellow","bold":true},{"score":{"name":"#s10","objective":"stream_data"},"color":"yellow","bold":true},{"score":{"name":"#s1","objective":"stream_data"},"color":"yellow","bold":true}]
title @a title {"text":"G'ALABA!","color":"gold","bold":true}
scoreboard players set #stage stream_data 7
function stream:goal_update
