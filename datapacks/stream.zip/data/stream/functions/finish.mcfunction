scoreboard players set #active stream_data 2
execute if score #best stream_data matches 0 run scoreboard players operation #best stream_data = #sec stream_data
execute if score #sec stream_data < #best stream_data run scoreboard players operation #best stream_data = #sec stream_data
function stream:calc
title @a times 10 80 20
title @a subtitle [{"text":"Vaqt: ","color":"gray"},{"score":{"name":"#min","objective":"stream_data"},"color":"yellow"},{"text":":","color":"yellow"},{"score":{"name":"#s10","objective":"stream_data"},"color":"yellow"},{"score":{"name":"#s1","objective":"stream_data"},"color":"yellow"}]
title @a title {"text":"G'ALABA!","color":"gold","bold":true}
