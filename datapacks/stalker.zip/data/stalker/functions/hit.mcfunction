tag @s add stalker_hit
scoreboard players set @s stalker_cd 60
damage @s 10 minecraft:magic
title @s times 5 40 10
title @s subtitle {"text":"Yana bir marta ushlasa - o'lasan!","color":"gray"}
title @s title {"text":"STALKER USHLADI!","color":"dark_red","bold":true}
playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 2 1
