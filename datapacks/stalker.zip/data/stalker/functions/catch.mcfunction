execute if entity @s[tag=stalker_hit] run function stalker:kill
execute unless entity @s[tag=stalker_hit] run function stalker:hit
