title @s times 5 30 10
title @s title {"text":"STALKER SENI TUTIB OLDI","color":"dark_red","bold":true}
playsound minecraft:entity.warden.sonic_boom master @s ~ ~ ~ 2 1
kill @s
