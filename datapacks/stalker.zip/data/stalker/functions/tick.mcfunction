# Ushlashdan keyingi himoya vaqtini kamaytirish
scoreboard players remove @a[scores={stalker_cd=1..}] stalker_cd 1
# O'lganda yoki lobbiga qaytganda holatni tiklash
execute as @a[scores={stalker_death=1..}] run function stalker:reset
execute as @a[x=10,y=70,z=-20,dx=25,dy=12,dz=40] if entity @s[tag=stalker_hit] run function stalker:reset
# Stalker o'yinchini ushlaganmi?
execute as @e[type=customnpcs:customnpc,tag=stalker,tag=!stalker_calm] at @s as @a[gamemode=!creative,gamemode=!spectator,distance=..2.2] unless score @s stalker_cd matches 1.. run function stalker:catch
