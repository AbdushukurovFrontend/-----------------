tag @s remove stalker_hit
scoreboard players set @s stalker_cd 0
scoreboard players reset @s stalker_death
