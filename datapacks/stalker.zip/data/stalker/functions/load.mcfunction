scoreboard objectives add stalker_cd dummy
scoreboard objectives add stalker_death deathCount
