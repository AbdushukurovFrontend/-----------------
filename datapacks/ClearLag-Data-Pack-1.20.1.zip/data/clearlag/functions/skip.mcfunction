scoreboard players operation #CL_TimeC ClearLag = #CL_Time ClearLag
execute unless score #CL_Time ClearLag matches 1 run tellraw @s [{"text":"[","color":"gold"},{"text":"ClearLag","color":"green"},{"text":"] "},{"text":"Siz bu tozalashni o'tkazib yubordingiz","color":"aqua"},{"text":"\n["},{"text":"ClearLag","color":"green"},{"text":"] "},{"text":"Keyingi tozalashgacha ","color":"aqua"},{"score":{"name":"#CL_TimeC","objective":"ClearLag"},"color":"gold"},{"text":" soniya","color":"dark_aqua"}]
execute if score #CL_Time ClearLag matches 1 run tellraw @s [{"text":"[","color":"gold"},{"text":"ClearLag","color":"green"},{"text":"] "},{"text":"Siz bu tozalashni o'tkazib yubordingiz","color":"aqua"},{"text":"\n["},{"text":"ClearLag","color":"green"},{"text":"] "},{"text":"Keyingi tozalashgacha ","color":"aqua"},{"score":{"name":"#CL_TimeC","objective":"ClearLag"},"color":"gold"},{"text":" soniya","color":"dark_aqua"}]

##Gamerule rollback##
gamerule sendCommandFeedback false
schedule function clearlag:other/system/gamerule 1t
