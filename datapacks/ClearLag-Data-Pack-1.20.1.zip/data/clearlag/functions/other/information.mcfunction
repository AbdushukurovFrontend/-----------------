tellraw @s [{"text":"[","color":"gold"},{"text":"ClearLag","color":"green"},{"text":"]"},{"text":" Statistika: ","color":"gray"},{"text":"(yangilash)","color":"gray","clickEvent":{"action":"run_command","value":"/function clearlag:other/information"}}]
tellraw @s [{"text":"Jami: ","color":"aqua"},{"score":{"name":"#CL_Total","objective":"ClearLag"},"color":"gold"},{"text":" ta buyum","color":"dark_aqua"}]
tellraw @s [{"text":"Eng ko'p: ","color":"aqua"},{"score":{"name":"#CL_Highest","objective":"ClearLag"},"color":"gold"},{"text":" ta buyum","color":"dark_aqua"}]
tellraw @s [{"text":"O'rtacha: ","color":"aqua"},{"score":{"name":"#CL_Average","objective":"ClearLag"},"color":"gold"},{"text":" ta buyum","color":"dark_aqua"}]
tellraw @s [{"text":"Soni: ","color":"aqua"},{"score":{"name":"#CL_Times","objective":"ClearLag"},"color":"gold"},{"text":" marta","color":"dark_aqua"}]

##Gamerule rollback##
gamerule sendCommandFeedback false
schedule function clearlag:other/system/gamerule 1t
