tellraw @s [{"text":"[","color":"gold"},{"text":"ClearLag","color":"green"},{"text":"] "},{"text":"Menyu: ","color":"yellow"},{"text":"(yangilash)","color":"gray","clickEvent":{"action":"run_command","value":"/function clearlag:menu"}}]
tellraw @s {"text":"Xabarlarni sozlash","color":"aqua","clickEvent":{"action":"run_command","value":"/function clearlag:messages"}}
tellraw @s {"text":"Statistika","color":"gray","clickEvent":{"action":"run_command","value":"/function clearlag:other/information"}}
tellraw @s {"text":"Sozlamalar","color":"gold","clickEvent":{"action":"run_command","value":"/function clearlag:other/menu"}}
tellraw @s [{"text":"Har bir tozalash oralig'i: ","color":"dark_aqua"},{"text":"[","color":"gray"},{"score":{"name":"#CL_Time","objective":"ClearLag"},"color":"gold","clickEvent":{"action":"suggest_command","value":"/scoreboard players set #CL_Time ClearLag TIME"},"hoverEvent":{"action":"show_text","value":"Soniyalarda"}},{"text":"] ","color":"gray"},{"text":"(qo'llash)","color":"green","clickEvent":{"action":"run_command","value":"/function clearlag:other/system/apply"}}]

##Gamerule rollback##
gamerule sendCommandFeedback false
schedule function clearlag:other/system/gamerule 1t
