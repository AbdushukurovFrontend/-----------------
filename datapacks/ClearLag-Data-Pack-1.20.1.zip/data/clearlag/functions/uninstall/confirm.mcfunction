tellraw @s [{"text":"[","color":"gold"},{"text":"ClearLag","color":"green"},{"text":"] "},{"text":"Datapackni o'chirishga ishonchingiz komilmi? ","color":"aqua"},{"text":"HA","bold":true,"color":"green","clickEvent":{"action":"run_command","value":"/function clearlag:uninstall/remove"}}]

##Gamerule rollback##
gamerule sendCommandFeedback false
schedule function clearlag:other/system/gamerule 1t
