##Message##
tellraw @a [{"text":"[","color":"aqua"},{"text":"ClearLag","color":"green"},{"text":"] "},{"text":"ClearLag","color":"green"},{"text":" datapack o'chirildi!","color":"yellow"}]

##Scoreboard##
scoreboard objectives remove ClearLag
scoreboard objectives remove ClearLagDeath

##Teams##
team remove CLnocollision
